bl_info = {
    "name":"Sparx Rigging tool",
    "author": "Nguyen Le Tri An",
    "version":(1, 0),
    "blender": (2, 80 ,0),
    "location":"VIEW 3D",    
}

import bpy, math, os, json, functools, datetime,re
from mathutils import Matrix
from bpy.types import Operator
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ImportHelper




########## FUNCTIONS ##########
#print(dir(bpy.ops.armature))

def TurnOnRigify(*arr):
    addonName =  "rigify"
    enabled = addonName in bpy.context.preferences.addons
    if not enabled:
        bpy.ops.preferences.addon_enable(module="rigify")
TurnOnRigify()

def ModeObject():
    if bpy.context.object:
        bpy.ops.object.mode_set(mode='OBJECT') 

def GetCurrentState():
    objs = [obj for obj in bpy.context.selected_objects]  # lưu tất cả selected objects
    active_obj = bpy.context.view_layer.objects.active      # lưu object active
    mode = bpy.context.object.mode if bpy.context.object else 'OBJECT'  # lưu mode, fallback OBJECT    
    return {
        "objs": objs,
        "active": active_obj,
        "mode": mode
    }

def BackPreviousState(data):
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')  
    bpy.ops.object.select_all(action='DESELECT')   
    for obj in data["objs"]:
        obj.select_set(True)    
    bpy.context.view_layer.objects.active = data["active"]  
    if data["mode"] != 'OBJECT' and data["active"]:
        bpy.context.view_layer.objects.active = data["active"]
        bpy.ops.object.mode_set(mode=data["mode"])    

def AddHumanRig(*arr):
    bpy.ops.object.armature_human_metarig_add()
    rig = bpy.context.object
    return(rig)

def RenameBone(rig,oldName,newName):
    rig.data.edit_bones[oldName].name = newName

def GeneralRig():
    before = set(bpy.data.objects)
    
    #Build
    rig = bpy.context.object 
    rig.select_set(True)
    bpy.ops.pose.rigify_generate()

    # Danh sách sau khi generate
    after = set(bpy.data.objects)
    new_objects = after - before

    rig = None
    for obj in new_objects:
        if obj.type == 'ARMATURE':
            rig = obj
            break    
    return(rig)

def AddType(arm,boneName,type):
    arm.pose.bones[boneName]["rigify_type"] = type

def GetAllBoneCollection(armature):
    returnArray = []
    collections = armature.data.collections
    for collection in collections:
        returnArray.append(collection.name)
    return(returnArray)

def CreateBoneCollection(armature,name):
    armature.data.collections.new(name)

def DeleteBoneCollection(armature,name):
    boneCollection = armature.data.collections.get(name)
    if boneCollection:
        armature.data.collections.remove(boneCollection)

def GetCollectionIndexByName(arm,name):
    cols = arm.data.collections
    colIndex = None
    for i,col in enumerate(cols):
        if col.name == name:
            return(i)
    return(None)
    
def DeleteAllCollection(armature):
    collections = armature.data.collections
    for collection in collections:
        if collection:
            DeleteBoneCollection(armature,collection.name)
        
def AssignBoneCollection(arm,colName,bones):
    boneCol = arm.data.collections.get(colName)
    if not boneCol:        
        CreateBoneCollection(arm,colName)
        boneCol = arm.data.collections.get(colName)
    for bone in bones:
        if isinstance(bone, str):
            boneTemp = arm.data.bones.get(bone)
        else:
            boneTemp = bone
        boneCol.assign(boneTemp)

def CreateRootCollection():
    arm = bpy.context.active_object    
    CreateBoneCollection(arm,"Root")

def CreateModule(data):
    arm = data["arm"]
    moduleName = data["moduleName"]
    if arm and arm.type == 'ARMATURE' and bpy.context.mode == 'EDIT_ARMATURE':
        bones = [bone for bone in arm.data.edit_bones if bone.select]
        AssignBoneCollection(arm,moduleName,bones)
    """
    CreateModule({
        "arm":bpy.context.active_object,
        "moduleName":"Arm.R",
    })    
    """
    
def ModifyUILayout(arm):
    cols = GetAllBoneCollection(arm)
    for i in range(len(cols)):        
        bpy.ops.armature.rigify_collection_select(index=0)
        bpy.ops.armature.rigify_collection_set_ui_row(index=i, row=(i+1))

def SceneCollectionGet(colName):
    if colName not in bpy.data.collections:
        col = bpy.data.collections.new(colName)
        bpy.context.scene.collection.children.link(col)
        return(col)
    else:
        return(bpy.data.collections.get(colName))
    
def DeleteAllLabel():
    for obj in list(bpy.data.objects):
        if obj.type == 'FONT' and obj.name.startswith("NLTA_Label"):
            bpy.data.objects.remove(obj, do_unlink=True)


def GetAllBone(arm):
    returnData = []
    bones = arm.data.bones
    for bone in bones:
        returnData.append(bone.name)
    return(returnData)

def CreateBoneLabel(arm,bone,text):
    currentState = GetCurrentState()
    ModeObject()
    
    #Tao text data
    name = "NLTA_Label"
    textData = bpy.data.curves.new(name=name, type='FONT')
    textData.body = text
    
    #Tao Object

    textObj = bpy.data.objects.new(name, textData)
    font = bpy.data.fonts.load("C:/Windows/Fonts/Arial.ttf")
    textObj.data.font = font
    
    textObj.rotation_euler[0] = 1.5708
    #textObj.rotation_euler[1] = -1.5708
    textObj.hide_select = True
    bpy.context.scene.collection.objects.link(textObj)
    textObj.color = (1,1, 0, 1)
    #textObj.show_wire = True
        
    # Copy Location
    con = textObj.constraints.new(type='COPY_LOCATION')
    con.target = arm
    con.subtarget = bone
    con.target_space = 'POSE'
    con.owner_space = 'WORLD'
    con.use_offset = True
    #textObj.location.x += 0.1
    textObj.location.z += 0.1
    
    BackPreviousState(currentState)
    
def ScaleLabel(percent):
    #ScaleLabel(.01)
    for obj in list(bpy.data.objects):
        if obj.type == 'FONT' and obj.name.startswith("NLTA_Label"):
            obj.scale = (percent,percent,percent)

def SetMaterial():
    mat = bpy.data.materials.get("NLTA_Material_Label")
    if textObj.data.materials:
        textObj.data.materials[0] = mat
    else:
        textObj.data.materials.append(mat)
        
def CreateMaterials():
    materialData = {
        "NLTA_Material_Label":(0,.5,.5,1)
    }
    for material in materialData:
        mat = bpy.data.materials.new(name=material)
        mat.use_nodes = True
        mat.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = materialData[material]
    
def DeleteMaterials():
    for mat in list(bpy.data.materials):
        if mat.name.startswith("NLTA_Material"):
            bpy.data.materials.remove(mat)

def SetObjectShading():
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    # Chuyển Solid shading sang Object color
                    space.shading.type = 'SOLID'
                    space.shading.color_type = 'OBJECT'  
    
def RigigfyCreateLabel(arm):
    DeleteAllLabel()
    labelData = {
        "spines.basic_spine":"Spine",
        "spines.super_head":"Head",
        "limbs.arm":"Arm",
        "basic.super_copy":"Copy",
        "limbs.leg":"Leg",
    }
    bones = GetAllBone(arm)
    for bone in bones:
        type = arm.pose.bones[bone].rigify_type
        if type != "":
            if type in labelData:
                CreateBoneLabel(arm,bone,labelData[type])
                
def ClearRigType(arm):
    bones = GetAllBone(arm)
    for bone in bones:
        arm.pose.bones[bone].rigify_type = ""
    
#SetObjectShading()
#RigigfyCreateLabel(bpy.context.object)
#ScaleLabel(.04)
#DeleteAllLabel()

def GetBonesSelected(arm):
    returnData = []
    selectedBones =  None
    if arm.mode == 'EDIT':
        selectedBones = [b for b in arm.data.edit_bones if b.select]
    elif arm.mode == 'POSE':
        selectedBones = [b for b in arm.pose.bones if b.bone.select]
    if selectedBones:
        for bone in selectedBones:
            returnData.append(bone.name)
    return(returnData)

def AddRigifyModule(arm,bone):
    pass

def ConstraintArmsBone(armSource,armTarget,boneSourceName,boneTargetName):
    boneTarget = armTarget.pose.bones[boneTargetName]
    con = boneTarget.constraints.new(type='COPY_TRANSFORMS')
    con.target = armSource
    con.subtarget = boneSourceName
    

def ApplyTransform(obj):
    oldState = GetCurrentState()    
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')    
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)    
    BackPreviousState(oldState)
    
 
def BoneParent(arm,parentName,childName):
    state = GetCurrentState()
    
    bpy.context.view_layer.objects.active = arm
    bpy.ops.object.mode_set(mode='EDIT')
    child = arm.data.edit_bones[childName]
    parent = arm.data.edit_bones[parentName]    
    parent.tail = child.head.copy()
    child.parent = parent
    child.use_connect = True
    
    BackPreviousState(state)
    
def BoneUnParent(arm,boneName):
    state = GetCurrentState()    
    
    bpy.context.view_layer.objects.active = arm
    bpy.ops.object.mode_set(mode='EDIT')
    child = arm.data.edit_bones[boneName]
    child.parent = None
    
    BackPreviousState(state)
    


###### PROPERTIES ######
bpy.types.Scene.session = {
    "modules":[],
    "type":{
        "spineBasic":{
            "label":"spines.basic_spine",
            "props":{
                "Name":"",
            }
        },
        "arm":{
            "label":"limbs.arm",
            "props":{
                "Name":"",
                "Segments":2,
            }
        },
    },
    "form":"",
}

class myProperties_PG(bpy.types.PropertyGroup):
    session = bpy.types.Scene.session
    """
    sourceSideRight:bpy.props.StringProperty(name="R",default=session["sourceSideRight"])
    sourceSideLeft:bpy.props.StringProperty(name="L",default=session["sourceSideLeft"])
    targetSideRight:bpy.props.StringProperty(name="R",default=session["targetSideRight"])
    targetSideLeft:bpy.props.StringProperty(name="L",default=session["targetSideLeft"])
    scaleExampleArmature:bpy.props.StringProperty(name="scaleExampleArmature",default=session["scaleExampleArmature"])
    scaleExampleBone:bpy.props.StringProperty(name="scaleExampleBone",default=session["scaleExampleBone"])
    exportFolder: bpy.props.StringProperty(
        name = "Custom Path",
        description = "Choose a directory:",
        subtype = "DIR_PATH",
        default=session["exportFolder"]
    )
    importFile: bpy.props.StringProperty(
        name = "Custom Path",
        description ="Choose a directory:",
        subtype = "FILE_PATH",
        default=session["importFile"]
    )
    """
        

# SPINE BASIC
class spineBasicProp_PG(bpy.types.PropertyGroup):
    type = "spineBasic"
    session = bpy.types.Scene.session
    props = session["type"][type]["props"]
    for prop in props:
        if prop == "Name":
            moduleName:bpy.props.StringProperty(name=prop,default=props[prop])
        if prop == "Segments":
            moduleSegments: bpy.props.IntProperty(name=prop,default=props[prop])
    
class openSpineBasic_OP(bpy.types.Operator):
    bl_label = "Open Spine Basic"
    bl_idname = "open.spinebasic"
    def execute(self, context):
        session = context.scene.session
        session["form"] = "spineBasic"
        return{'FINISHED'}
    
class addSpineBasic_OP(bpy.types.Operator):
    bl_label = "Add Module"
    bl_idname = "add.spinebasic"
    def execute(self, context):
        session = context.scene.session
        prop = context.scene.spineBasicProp        
        arm = bpy.context.active_object
        if arm.type == "ARMATURE":
            bones = GetBonesSelected(arm)
            moduleName = prop.moduleName
            for i in range(len(session["modules"])):
                if session["modules"][i]["moduleName"] == moduleName:
                    session["modules"][i]["bones"] = bones
                    session["modules"][i]["type"] = "spineBasic"
                    prop.moduleName = ""
                    return{'FINISHED'}
            
            session["modules"].append({            
                "moduleName":prop.moduleName,
                "bones":bones,
                "type":"spineBasic",
            })
            prop.moduleName = ""
        return{'FINISHED'}
    

# Arm
class armProp_PG(bpy.types.PropertyGroup):
    type = "arm"
    session = bpy.types.Scene.session
    props = session["type"][type]["props"]
    for prop in props:
        if prop == "Name":
            moduleName:bpy.props.StringProperty(name=prop,default=props[prop])
        if prop == "Segments":
            moduleSegments: bpy.props.IntProperty(name=prop,default=props[prop])
    
class openArm_OP(bpy.types.Operator):
    bl_label = "Open Arm Basic"
    bl_idname = "open.arm"
    def execute(self, context):
        session = context.scene.session
        session["form"] = "arm"
        return{'FINISHED'}
    
class addArm_OP(bpy.types.Operator):
    bl_label = "Add Module"
    bl_idname = "add.arm"
    def execute(self, context):
        session = context.scene.session
        prop = context.scene.armProp        
        arm = bpy.context.active_object
        if arm.type == "ARMATURE":
            bones = GetBonesSelected(arm)
            moduleName = prop.moduleName
            for i in range(len(session["modules"])):
                if session["modules"][i]["moduleName"] == moduleName:
                    session["modules"][i]["bones"] = bones
                    session["modules"][i]["type"] = "arm"
                    prop.moduleName = ""
                    return{'FINISHED'}
            
            session["modules"].append({            
                "moduleName":prop.moduleName,
                "bones":bones,
                "type":"arm",
            })
            prop.moduleName = ""
        return{'FINISHED'}
    


### GENERAL
class generate_OP(bpy.types.Operator):
    bl_label = "Add Module"
    bl_idname = "build.generate"
    def execute(self, context):
        session = context.scene.session
        type = session["type"]
        arm = bpy.context.active_object       
        
        if arm.type == "ARMATURE":
            ClearRigType(arm)
            DeleteAllCollection(arm)
            CreateRootCollection()   
            ApplyTransform(arm)            
            
            for module in session["modules"]:
                moduleType = module["type"]
                colName = module["moduleName"]
                bones = module["bones"]
                if moduleType in ["spineBasic","arm"]:
                    for i in range(len(bones)):
                        if i!=0:
                            BoneParent(arm,bones[i-1],bones[i])
                    arm.pose.bones[bones[0]]["rigify_type"] = type[moduleType]["label"]

                    
                AssignBoneCollection(arm,colName,bones)
            ModifyUILayout(arm)
            rig = GeneralRig()
            
            for module in session["modules"]:
                bones = module["bones"]
                for bone in bones:
                    BoneUnParent(arm,bone)
                    ConstraintArmsBone(rig,arm,"ORG-"+bone,bone)                       
                    
        return{'FINISHED'}


  

###### MAIN FORM #######

class mainForm_PT(bpy.types.Panel):
    bl_label = "Sparx*"
    bl_idname = "NLTA.main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Sparx tool'
    def draw(self,context):
        
        session = context.scene.session
        
        layout = self.layout
        layout.scale_y = 1.6
        
        box = layout.box()
        row = box.row()
        row.operator("open.spinebasic", text="Add Spine")
        row.operator("open.arm", text="Add Arm")
        
        box = layout.box()
        if session["form"]!="":
            if session["form"] == "spineBasic":
                prop = context.scene.spineBasicProp                
                row = box.row()
                row.prop(prop,"moduleName")
                row = box.row()
                row.operator("add.spinebasic", text="Ok")
            if session["form"] == "arm":
                prop = context.scene.armProp
                row = box.row()
                row.prop(prop,"moduleName")
                row = box.row()
                row.operator("add.arm", text="Ok")
                
        
        itemsBox = layout.box()
        for module in session["modules"]:
            moduleRow = itemsBox.row()
            moduleRow.label(text=module["moduleName"])
        
        box = layout.box()
        row = box.row()
        row.operator("build.generate", text="Generate")


        
        

#####
# RUN
#####

classArray = [  
    myProperties_PG,
    mainForm_PT,
      
    spineBasicProp_PG,
    openSpineBasic_OP, 
    addSpineBasic_OP,
    
    armProp_PG,
    openArm_OP, 
    addArm_OP,
    
    generate_OP,
    
]

def register():
    for classItem in classArray:
        bpy.utils.register_class(classItem)
    bpy.types.Scene.spineBasicProp = bpy.props.PointerProperty(type=spineBasicProp_PG)
    bpy.types.Scene.armProp = bpy.props.PointerProperty(type=armProp_PG)
    bpy.types.Scene.myProp = bpy.props.PointerProperty(type=myProperties_PG)
    

def unregister():
    for classItem in classArray:
        try:
            bpy.utils.unregister_class(classItem)
        except:pass


if __name__ == "__main__":
    register()
    