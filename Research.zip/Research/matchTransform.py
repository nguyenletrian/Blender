import bpy,math
#bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))


#Euler Rotation transfer

"""
arm = bpy.context.scene.objects["Armature"]
#arm.matrix.location
for bone in arm.pose.bones:
    print(bone.name)
    boneMatrix = bone.matrix
    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location= boneMatrix.to_translation(), scale=(1, 1, 1))
    empty = bpy.context.selected_objects[0]
    boneRotation = boneMatrix.to_euler()
    empty.rotation_euler[0] = boneRotation.x
    empty.rotation_euler[1] = boneRotation.y
    empty.rotation_euler[2] = boneRotation.z
"""

"""  
import bpy

# Select your armature object in object mode
context = bpy.context
armature = context.object

# Get the armature's world matrix
armature_world_matrix = armature.matrix_world

# Iterate over each pose bone
for pose_bone in armature.pose.bones:
    # Add an empty at the bone's location
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(armature_world_matrix @ pose_bone.matrix).translation)
    empty = context.object
    empty.name = f"MT_{pose_bone.name}"  # Rename the empty
    # Create a child-of constraint
    constraint = empty.constraints.new(type='CHILD_OF')
    constraint.target = armature
    constraint.subtarget = pose_bone.name
    # Calculate the inverted matrix for the constraint
    inverted_matrix = (armature_world_matrix @ pose_bone.matrix).inverted()
    constraint.inverse_matrix = inverted_matrix
"""

"""
import bpy

# Specify the name of your armature
armature_name = "Armature"

# Get the active bone
active_bone = bpy.context.active_pose_bone

# Calculate the world coordinates of the bone's head and tail
head_world = bpy.data.objects[armature_name].matrix_world @ active_bone.head
tail_world = bpy.data.objects[armature_name].matrix_world @ active_bone.tail

# Print the coordinates to the console
print("Head World:", head_world)
print("Tail World:", tail_world)L

bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location= head_world, scale=(1, 1, 1))

# Set the location of the Empty objects
#bpy.data.objects["Empty.head"].location = head_world
#bpy.data.objects["Empty.tail"].location = tail_world
"""

"""
########## MATCH OBJECT TO BONE #######################
import bpy
from bpy import context
pose_bone = context.active_pose_bone

obj = pose_bone.id_data
print(obj)
matrix_final = obj.matrix_world @ pose_bone.matrix

obj_empty = bpy.data.objects.new("test",None)
context.collection.objects.link(obj_empty)
obj_empty.matrix_world =  matrix_final
"""

"""
import bpy

armature = bpy.data.objects['Armature.001']
poseBone = armature.pose.bones['Bone']
object = bpy.data.objects["test"]
#poseBone.location.x = 0

# Set the desired world space position (e.g., (1, 2, 3))
objectMatrix = object.matrix_world

localPosition = armature.matrix_world.inverted() @ objectMatrix
#localPosition = localPosition.to_translation()
poseBone.matrix = localPosition
#poseBone.location.x = localPosition.x #target_position
#poseBone.location.y = localPosition.y
#poseBone.location.z = localPosition.z

#bpy.data.objects['Armature.001'].pose.bones['Bone'].matrix = objectMatrix


"""
 
import bpy

def createEmptyFromBone():
    poseBone = bpy.context.active_pose_bone
    armature = poseBone.id_data
    armatureMatrix = armature.matrix_world
    poseBoneMatrix = poseBone.matrix    
    resultMatrix = armatureMatrix @ poseBoneMatrix    
    
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location= (0,0,0), scale=(1, 1, 1))
    empty = bpy.context.selected_objects[0]
    empty.matrix_world = resultMatrix

def getArmature():
    poseBone = bpy.context.active_pose_bone
    return(poseBone.id_data)

def getBoneTransfrom(armatureName,boneName):
    armature = bpy.data.objects[rmatureName]
    bonePose = armature.pose.bones[boneName]
    return(armature.matrix_world @ bonePose.matrix)

def matchBoneToObject(armatureName,boneName,object):
    armature = bpy.data.objects[armatureName]
    poseBone = armature.pose.bones[boneName]
    object = bpy.data.objects[object]
    
    #objectMatrix = object.matrix_world
    #poseBoneNewMatrix =  armature.matrix_world.inverted() @ objectMatrix
    #poseBone.matrix = poseBoneNewMatrix
    poseBone.location.x =20
    
def matchObjectToBone(armatureName,boneName,object):
    armature = bpy.data.objects[armatureName]
    poseBone = armature.pose.bones[boneName]
    object = bpy.data.objects[object]    
    matrixFinal = armature.matrix_world @ poseBone.matrix
    object.matrix_world = matrixFinal

def matchBoneToBone(armatureName1,boneName1,armatureName2,boneName2):
    armature1 = bpy.data.objects[armatureName1]
    poseBone1 = armature1.pose.bones[boneName1]
    armature2 = bpy.data.objects[armatureName2]
    poseBone2 = armature2.pose.bones[boneName2]
    
    poseBone1Matrix = armature1.matrix_world @ poseBone1.matrix
    poseBone2Matrix = armature2.matrix_world.inverted() @ poseBone1Matrix
    poseBone2.matrix = poseBone2Matrix
    
#matchObjectToBone("Armature","Bone.002","Empty")

#matchBoneToObject("Armature","Bone.002","Empty")

#createEmptyFromBone()
matchBoneToBone("Armature","Bone.001","Armature.001","Bone.001")

    
    
    






