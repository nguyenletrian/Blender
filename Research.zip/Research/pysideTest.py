import sys,os,bpy
user = os.environ.get("USERNAME")
setupFolder = "C:/Users/"+user+"/Documents/maya/scripts/NLTA/"
pathArray = [
"C:/vsTools2/library/python_module/PySide2-5.15.2.1",
"C:/vsTools2/library/python_module/PySide2-5.15.2.1"
]

for path in pathArray:
    if path not in sys.path:
        sys.path.append(path)
        
        
import bpy
import sys
from PySide2.QtWidgets import QApplication, QMainWindow, QPushButton,QWidget,QVBoxLayout,QPushButton
from PySide2.QtCore import QTimer,Qt
mainWindow = None
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.setFixedWidth(300)
        widget = QWidget()
        layout = QVBoxLayout()
        widget.setLayout(layout)
        self.setCentralWidget(widget)
        button = QPushButton('Add UVSphere')
        button.setFixedSize(280,50)
        button.clicked.connect(self.button_pressed)
        layout.addWidget(button)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(100)
        
    def button_pressed(self):
        self.num = self.num if hasattr(self,'num') else 0
        bpy.ops.mesh.primitive_uv_sphere_add(location=(2.0*self.num,0,0))
        self.num +=1
        active_object = bpy.context.view_layer.objects.active
        if active_object:
            print("Active object:", active_object.name)
        else:
            print("No active object.")
        
    def update(self):
        if bpy.context.view_layer.objects.active!=None:
            title = bpy.context.view_layer.objects.active.name
            self.setWindowTitle(title)
    def closeEvent(self,event):
        global mainWindow
        mainWindow = None
        self.timer.stop()
        event.accept()
if QApplication.instance() is None:
    QApplication(["blender"])
window = MainWindow()
window.show()
