import bpy,math

rotation = bpy.context.active_pose_bone.matrix.to_euler()
print(math.degrees(rotation.x))
bpy.context.active_pose_bone.rotation_mode = 'XYZ'
bpy.context.active_pose_bone.rotation_euler.rotate_axis("X",math.radians(90))
"""
changeNumber = 0.1
degrees = math.degrees(0.1)
print(degrees)
bpy.context.active_pose_bone.rotation_euler[0] = changeNumber
"""


"""
arm = bpy.data.objects["Lily_Armature"]
bone = arm.pose.bones["spine_3_C_1"]
matrix = bone.matrix.to_euler()
print(math.degrees(matrix.x))
print(math.degrees(matrix.y))
print(math.degrees(matrix.z))
"""

