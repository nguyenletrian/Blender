bl_indo = {
    "name":"Sparx Rigging tool",
    "author": "Nguyen Le Tri An",
    "version":(1, 0),
    "blender": (2, 80 ,0),
    "location":"VIEW 3D",    
}
import bpy,random,math,os
"""
import bpy,sys,os,importlib
user = os.environ.get("USERNAME")
if "C:/Users/"+user+"/Documents/maya/scripts/NLTA" not in sys.path:
    sys.path.append("C:/Users/"+user+"/Documents/maya/scripts/NLTA")
import ta_index
"""
    
class mainUI(bpy.types.Panel):
    bl_label = "Sparx*"
    bl_idname = "NLTA.main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Sparx tool'
    def draw(self,context):
        layout = self.layout

class animationUI(bpy.types.Panel):#sub panel
    bl_label = "Rigging tool"
    bl_idname = "NLTA.animation"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_parent_id = "NLTA.main"
    bl_options = {"DEFAULT_CLOSED"}#DEK WORK
    
    def draw(self,context):
        layout = self.layout
        layout.scale_y = 1.6
        #obj = context.object
        #bpy.ops.view3d.snap_selected_to_active()
        #row.operator("transform.resize")
        #col.prop(obj,"scale")
        row = layout.row()
        row.operator("animation.create_animation",text="Create Animation")   

def angle(input):    
    return(math.radians(input))
          
class createAnimation(bpy.types.Operator):
    bl_label = "Create Animation"
    bl_idname = "animation.create_animation"
    def execute(self,context):
        print("a")
        bpy.ops.mesh.primitive_cube_add()
        currentObj = bpy.context.active_object
        currentObj.name = "Nguyen le tri n"
        currentObj.rotation_euler.z = angle(90)
        currentObj.location.z = 2
        print(bpy.data.filepath)
        print(bpy.utils.script_path_user())
        print(os.path.realpath(__file__))
        print(os.path.abspath(__file__))
        print(os.path.dirname(__file__))
        return{'FINISHED'}
        
class riggingUI(bpy.types.Panel):#sub panel
    bl_label = "Rigging tool"
    bl_idname = "NLTA.rigging"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_parent_id = "NLTA.main"
    bl_options = {"DEFAULT_CLOSED"}#DEK WORK
    
    def draw(self,context):
        layout = self.layout
        layout.scale_y = 1.6
        #obj = context.object
        
        row = layout.row()
        row.label(text="Match transfrom",icon="CON_TRACKTO")
        #bpy.ops.view3d.snap_selected_to_active()
        #row.operator("transform.resize")
        col = layout.column()#arrange elements as column
        #col.prop(obj,"scale")
        row = layout.row()
        row.operator("mesh.primitive_cube_add",text="Match transfrom",icon="CON_TRACKTO")
        
        """
        row = layout.row()
        row.operator("object.shade_smooth",text="Shade smooth")
        row = layout.row()
        row.operator("object.subdivision_set",text="Add Subdivision")
        row = layout.row()
        row.operator("object.modifier_add",text="Add modifier")
        row = layout.row()
        row.operator("shader.diamon",text="Diamon Shader")
        row = layout.row()
        row.operator("nlta.createcube",text="Create Cube Dialog")
        """
        row = layout.row()
        row.operator("nlta.createtext",text="Create Text Dialog")
        row = layout.row()
        row.operator("node.use_node",text="Create group node")
        row = layout.row()
        row.operator("nlta.confirm",text="Confirm popup")
        
        #GLOBALE PROPERTIES
        scene = context.scene
        mytool = scene.my_tool
        layout.prop(mytool,"myString")
        layout.prop(mytool,"myFloatVector")
        layout.prop(mytool,"myEnum")#expand=True
        layout.label(text=mytool.textList[mytool.myRandomNumber])
        layout.prop(mytool,"myRandomNumber")
        row = layout.row()  
        row.operator("nlta.change_random",text="Change Random")
        row = layout.row()  
        row.operator("nlta.globalproperties",text="Global Properties")   
        row = layout.row() 
        row.operator("nlta.message",text="Message")   
        
class diamonShader(bpy.types.Operator):
    bl_label = "Change shader"
    bl_idname = "shader.diamon"
    def execute(self,context):
        diamond = bpy.data.materials.new(name="Diamond")
        diamond.use_nodes = True
        diamond.node_tree.nodes.remove(diamond.node_tree.nodes.get('Principled BSDF'))
        outputNode = diamond.node_tree.nodes.get('Material Output')
        outputNode.location = (400,0)
        
        glass1Node = diamond.node_tree.nodes.new('ShaderNodeBsdfGlass')
        glass1Node.location = (-600,0)
        glass1Node.inputs[0].default_value = (1,0,0,1) #color
        glass1Node.inputs[2].default_value = 1.446 #IOR
        
        glass2Node = diamond.node_tree.nodes.new('ShaderNodeBsdfGlass')
        glass2Node.location = (-600,-150) #x,y
        glass2Node.inputs[0].default_value = (0,1,0,1) #color
        glass2Node.inputs[2].default_value = 1.450 #IOR
        
        glass3Node = diamond.node_tree.nodes.new('ShaderNodeBsdfGlass')
        glass3Node.location = (-600,-300) #x,y
        glass3Node.inputs[0].default_value = (0,0,1,1) #color
        glass3Node.inputs[2].default_value = 1.450 #IOR
        
        add1Node = diamond.node_tree.nodes.new('ShaderNodeAddShader')
        add1Node.location = (-400,-50)
        add1Node.label = "Add 1"
        add1Node.hide = True #minizie
        add1Node.select = False
        
        add2Node = diamond.node_tree.nodes.new('ShaderNodeAddShader')
        add2Node.location = (-100,0)
        add2Node.label = "Add 2"
        add2Node.hide = True #minizie
        add2Node.select = False
        
        glass4Node = diamond.node_tree.nodes.new('ShaderNodeBsdfGlass')
        glass4Node.location = (-150,-150) #x,y
        glass4Node.inputs[0].default_value = (1,1,1,1) #color
        glass4Node.inputs[2].default_value = 1.450 #IOR
        glass4Node.select = False
        
        mix1Node = diamond.node_tree.nodes.new('ShaderNodeMixShader')
        mix1Node.location = (200,0)
        mix1Node.select = False
        
        diamond.node_tree.links.new(glass1Node.outputs[0],add1Node.inputs[0])
        diamond.node_tree.links.new(glass2Node.outputs[0],add1Node.inputs[1])
        
        diamond.node_tree.links.new(add1Node.outputs[0],add2Node.inputs[0])
        
        diamond.node_tree.links.new(glass3Node.outputs[0],add2Node.inputs[1])
        
        diamond.node_tree.links.new(add2Node.outputs[0],mix1Node.inputs[1])
        diamond.node_tree.links.new(glass4Node.outputs[0],mix1Node.inputs[2])
        diamond.node_tree.links.new(mix1Node.outputs[0],outputNode.inputs[0])
        
        bpy.context.object.active_material = diamond
        
        tree = diamond.node_tree
        cur_frame = bpy.context.scene.frame_current
        glass4Node.inputs[2].keyframe_insert('default_value',frame=cur_frame)
        
        data_path = f'nodes["{glass4Node.name}"].inputs[2].default_value'
        fcurves = tree.animation_data.action.fcurves
        fc = fcurves.find(data_path)
        if fc:
            new_mod = fc.modifiers.new('NOISE')
            new_mod.strength = 10
            new_mod.depth = 1
              
        return{'FINISHED'}

class createMesh(bpy.types.Operator):
    bl_label = "Add CUbe Dialog Box"
    bl_idname = "nlta.createcube"
    
    text: bpy.props.StringProperty(name="Enter Text",default="")
    #number = bpy.props.FloatProperty(name="Scale Z Axis",default=1)
    scale: bpy.props.FloatVectorProperty(name="Scale",default= (1,1,1))
    
    def execute(self,context):
        t = self.text
        s = self.scale
        bpy.ops.mesh.primitive_cube_add()
        obj = bpy.context.object
        obj.name = t
        #obj.scale[2] = number
        obj.scale[0] = s[0]
        obj.scale[1] = s[1]
        obj.scale[2] = s[2]
        return{'FINISHED'}
    
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self)

class createText(bpy.types.Operator):
    bl_label = "Add Text Dialog Box"
    bl_idname = "nlta.createtext"
    
    text: bpy.props.StringProperty(name="Enter Text",default="")
    scale: bpy.props.FloatProperty(name="Scale:",default=1)
    rotation: bpy.props.BoolProperty(name="Z up",default=False)
    center: bpy.props.BoolProperty(name="Center Origin",default=False)
    extrude: bpy.props.BoolProperty(name="Extrude",default=False)
    extrude_amount: bpy.props.FloatProperty(name="Extrude Amount:",default=0.06)
    
    def draw(self,context):
        layout = self.layout
        layout.label(text="Sample Text")
        
        row = layout.row()
        row.prop(self,"text")#Bring "text" property upper to here
        row.prop(self,"scale")
        
        layout.separator(factor=10)
        
        box = layout.box()
        row = box.row()
        row.prop(self,"rotation")
        if self.rotation ==True:
            row.label(text="Orientation: Z UP",icon="EMPTY_SINGLE_ARROW")
        elif self.rotation == False:
            row.label(text="Orientation: Default",icon="ARROW_LEFTRIGHT")    
            
        box.prop(self,"center")
        
        row = box.row()
        row.prop(self,"extrude")
        if self.extrude == True:
            row.prop(self,"extrude_amount")
    
    def execute(self,context):       
        t = self.text
        bpy.ops.object.text_add(enter_editmode=True)
        bpy.ops.font.delete(type='PREVIOUS_WORD')
        bpy.ops.font.text_insert(text=t)
        bpy.ops.object.editmode_toggle()
        
        s = self.scale
        obj = bpy.context.object
        obj.scale[0] = s
        obj.scale[1] = s
        obj.scale[2] = s
        
        c = self.center
        if c == True:
            bpy.context.object.data.align_x = 'CENTER'
            bpy.context.object.data.align_y = 'CENTER'
            
        e = self.extrude
        em = self.extrude
        if e != False:
            bpy.context.object.data.extrude = em
        else:
            bpy.context.object.data.extrude = 0.06

        
        return{'FINISHED'}
    
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self)
    
def createNode(context,operator,group_name):
    groupName = "NguyenLeTriAn"
    bpy.context.scene.use_nodes = True
    groupNew = bpy.data.node_groups.new(groupName,"CompositorNodeTree")
    
    groupIn = groupNew.nodes.new("NodeGroupInput")
    groupIn.location = (-200,0)
    groupNew.inputs.new('NodeSocketFloat','Factor Value')
    groupNew.inputs.new('NodeSocketColor','Color Input')
    
    groupOut = groupNew.nodes.new("NodeGroupOutput")
    groupOut.location = (400,0)
    groupNew.outputs.new("NodeSocketColor","Output")
    
    maskNode = groupNew.nodes.new(type='CompositorNodeBoxMask')
    maskNode.location = (0,0)
    maskNode.rotation = 1
    
    mixNode = groupNew.nodes.new(type="CompositorNodeMixRGB")
    mixNode.location = (200,0)
    mixNode.use_clamp = True
    mixNode.blend_type = 'OVERLAY'
    
    link = groupNew.links.new
    link(maskNode.outputs[0],mixNode.inputs[1])
    link(groupIn.outputs['Factor Value'],mixNode.inputs[0])
    link(groupIn.outputs[1],mixNode.inputs[2])
    link(mixNode.outputs[0],groupOut.inputs[0])     
    return groupNew

  
class useNode(bpy.types.Operator):
    bl_label = "Add custom node group"
    bl_idname = "node.use_node"
    def execute(self,context):
        customNodeName = "Test Node"
        #context,operator,group_name
        newGroup = createNode(self,context,customNodeName)
        newNode = context.scene.node_tree.nodes.new('CompositorNodeGroup')
        newNode.node_tree = bpy.data.node_groups[newGroup.name]
        newNode.use_custom_color = True
        newNode.color = (0.5,0.4,0.3)
        return {'FINISHED'}
    
class confirm(bpy.types.Operator):
    bl_label = "Confirm popup"
    bl_idname = "nlta.confirm"
    
    preset_enum:bpy.props.EnumProperty(
        name = "",
        description = "select an option",
        items = [
            ('OP1',"Cube","Add a Cube to the scene"),
            ('OP2',"Sphere",""),
            ('OP3',"Suzanne","Add Suzanne to the scene")
        ]
    )
    
    other_preset_enum:bpy.props.EnumProperty(
        name = "",
        description = "select an option",
        items = [
            ('OP1',"Cube","Add a Cube to the scene"),
            ('OP2',"Sphere",""),
            ('OP3',"Suzanne","Add Suzanne to the scene")
        ]
    )
    
    def invoke(self,context,event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
    def draw(self,context):
        layout = self.layout
        layout.prop(self,"preset_enum")
        layout.prop(self,"other_preset_enum")  
    
    def execute(self,context):
        
        if self.preset_enum == "OP1":
            bpy.ops.mesh.primitive_cube_add()
        if self.preset_enum == "OP2":
            bpy.ops.mesh.primitive_uv_sphere_add()
        if self.preset_enum == "OP3":
            bpy.ops.mesh.primitive_monkey_add() 
        
        return{'FINISHED'}

class myProperties(bpy.types.PropertyGroup):
    myRandomNumber:bpy.props.IntProperty(name="Random Number",default=0)
    myString:bpy.props.StringProperty(name="Enter Text")
    myFloatVector:bpy.props.FloatVectorProperty(name="Enter Value",soft_min=0,soft_max=1000,default=(1,1,1))
    myEnum:bpy.props.EnumProperty(
        name = "Enumerator / Dropdown",
        description = "sample text",
        items = [
            ("OP1","Cube",""),
            ("OP2","Sphere",""),
            ("OP3","Money",""),
        ]
    )
    textList = ["A","B","C"]
    
class myPropertiesOperation(bpy.types.Operator):
    bl_label = "Operator"
    bl_idname = "nlta.globalproperties"
    bl_options = {"REGISTER","UNDO"}
    loc:bpy.props.FloatVectorProperty()
    
    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool
        if mytool.myEnum == "OP1":
            bpy.ops.mesh.primitive_cube_add(location= (self.loc))
            bpy.context.object.name = mytool.myString
            bpy.context.object.scale[0] = mytool.myFloatVector[0]
            bpy.context.object.scale[1] = mytool.myFloatVector[1]
            bpy.context.object.scale[2] = mytool.myFloatVector[2]
            
        if mytool.myEnum == "OP2":
            bpy.ops.mesh.primitive_uv_sphere_add()
            bpy.context.object.name = mytool.myString
            bpy.context.object.scale[0] = mytool.myFloatVector[0]
            bpy.context.object.scale[1] = mytool.myFloatVector[1]
            bpy.context.object.scale[2] = mytool.myFloatVector[2]
            
        if mytool.myEnum == "OP3":
            bpy.ops.mesh.primitive_monkey_add()
            bpy.context.object.name = mytool.myString
            bpy.context.object.scale[0] = mytool.myFloatVector[0]
            bpy.context.object.scale[1] = mytool.myFloatVector[1]
            bpy.context.object.scale[2] = mytool.myFloatVector[2]
            
        return{"FINISHED"}

class changeRandom(bpy.types.Operator):
    bl_label = "Operator"
    bl_idname = "nlta.change_random"
    
    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool
        
        x = random.choice(range(0,2))
        mytool.myRandomNumber = x
        return{"FINISHED"}
    
class message(bpy.types.Operator):
    bl_label = "Operator"
    bl_idname = "nlta.message"
    
    def execute(self,context):
        #INFO, WARNING,ERROR
        #self.report({'WARNING'},"If you prefer a non-Python solution, you can manually import materials using the Blender GUI")        
        bpy.ops.wm.open_mainfile(filepath="")
        return{"FINISHED"}
    
    
     
classArray = [
    mainUI,
    riggingUI,
    animationUI,
    createAnimation,
    diamonShader,
    createMesh,
    createText,
    useNode,
    confirm,
    myProperties,
    myPropertiesOperation,
    changeRandom,
    message
]

addon_keymaps = []

def register():
    for a in classArray:
        bpy.utils.register_class(a)
    
    #keymap shortcut key  
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='3D View',space_type='VIEW_3D')
        kmi = km.keymap_items.new("nlta.createtext",type='F',value='PRESS',shift=True)
        addon_keymaps.append((km,kmi))
    
    #myProperties
    bpy.types.Scene.my_tool = bpy.props.PointerProperty(type=myProperties)
        
        
def unregister():
    for a in classArray: 
        bpy.utils.unregister_class(a)
        
    #keymap shortcut key  
    for km.kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    
    #myProperties

    
if __name__ == "__main__":
    register()
    
"""
list(bpy.data.objects)
list(bpy.data.materials)
bpy.data.materials.new("My Material")
bpy.data.materials["My Material"].use_nodes = True

myList = []
a = "alpha"
b = "beta"
myList.append(a)
myList.remove(a)
myList.extend((a,b))
myList.clear()

------------
import bpy
def in_5_seconds():
    print("This Works")
    bpy.ops.mesh.primitive_cube_add()
bpy.app.timers.register(in_5_seconds,first_interval=5)

-----------------
import bpy

counter = 0
loc = 0

def run_10_times():
    global loc
    global counter
    bpy.ops.mesh.primitive_cube_add(location=(0,loc,0))
    counter +=1
    loc +=2
    if counter == 10:
        return None
    return 0.5
bpy.app.timers.register(run_10_times)

----------------

import bpy

bpy.ops.wm.open_mainfile(filepath="")

# Specify the path to your FBX file
filepath = "/path/to/your/file.fbx"

# Import the FBX file
bpy.ops.import_scene.fbx(filepath=filepath, use_anim=True)

# Optional: Print a message to confirm successful import
print(f"FBX animation imported from {filepath}")

"""