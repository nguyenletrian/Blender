import bpy

class HelloWorldIdPanel(bpy.types.Panel):
	"""Creates a Panel in the Object properties window"""
	bl_label = "Hello World Panel"
	bl_idname = "OBJECT_PT_hello"
	bl_space_type="PROPERTIES"
	bl_region_type = "WINDOW"
	bl_context = "object"

	def draw(self,context):
		layout = self.layout
		layout.prop(context.scene,"prop1")
		layout.prop(context.scene,"prop2")

def items_prop1(self,context):
	types = {ob.type:ob.type for ob in context.scene.objects}
	return [(t,t,"") for t in types]

def items_prop2(self,context):
	return[(ob.name,ob.name,"") for ob in context.scene.objects if ob.type == context.scene.prop1]

def update_prop1(self,context):
	print("Prop1 changed to",context.scene.prop1)

def update_prop2(self,context):
	print("Prop2 changed to",context.scene.prop2)

def register():
	bpy.utils.register_class(HelloWorldIdPanel)
	bpy.types.Scene.prop1 = bpy.props.EnumProperty(name="Type",items=items_prop1,update=update_prop1)
	bpy.types.Scene.prop2 = bpy.props.EnumProperty(name="Name",items=items_prop2,update=update_prop2)


def unregister():
	bpy.utils.unregister_class(HelloWorldIdPanel)
	del bpy.types.Scene.prop1
	del bpy.types.Scene.prop2

if __name__ == "__main__":
	register()