import bpy

bl_info = {
    "name":"Mass Importer",#name of add on,
    "author":"Nguyen Le Tri An",
    "version":(1, 0), 
    "blender":(2, 83, 0),
    "category":"Mesh",
    "location":"Operator Search",
    "description":'More Monkeys',
    "warning":""
}

class IMPORT_SCENE_OT_obj_mass(bpy.types.Operator):
    bl_idname = 'import_scene.obj_mass'
    bl_label = 'Mass-import OBJs'
    
    def execute(self,context):
        #bpy.ops.import_scene.obj(filepath='')
        self.report(
            {'ERROR'},
            f'No code to load from{context.scene.mass_import_path}'
        )
        return{'CANCELLED'}

class VIEW3D_PT_mass_import(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Monkeys"
    bl_label = "Mass Import"
    
    def draw(self,context):
        layout = self.layout
        col = layout.column(align=True)
        col.prop(context.scene,'mass_import_path')
        col.operator('import_scene.obj_mass')
        
        col.layout.column(align=True)
        if context.object:
            col.prop(context.object,'mass_import_fname')
        else:
            col.label(text='-no active object-')
    
blender_classes = [
    VIEW3D_PT_mass_import,
    IMPORT_SCENE_OT_obj_mass
]


def register():
    bpy.types.Scene.mass_import_path = bpy.props.StringProperty(
        name='OBJ Folder',
        subtype='DIR_PATH',
    )
    bpy.types.Object.mass_import_fname = bpy.props.StringProperty(
        name = 'OBJ File',
    )
    for blender_class in blender_classes:        
        bpy.utils.register_class(blender_class)
    
def unregister():
    del bpy.types.Scene.mass_import_path
    for blender_class in blender_classes:   
        bpy.utils.unregister_class(blender_class)
    
""" if not use scrip as add-on
if __name__ == '__main__':
    register()
"""