import bpy


class HelloWorldPanel(bpy.types.Panel):
    bl_label = "NLTA Keyframe tool"
    bl_idname = "OBJECT_PT_hello"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Keyframe'

    def draw(self, context):
        layout = self.layout

        obj = context.object

        row = layout.row()
        row.operator('shader.neon_operator')

class SHADER_OT_NEON(bpy.types.Operator):
    bl_label = "Add Neon Shader"
    bl_idname = 'shader.neon_operator'
    
    def execute(self,context):
        cur_frame = bpy.context.scene.frame_current
              
    #Creating a new shader and calling it Neon
        material_neon = bpy.data.materials.new(name="Neon")
    #Enabling use nodes
        material_neon.use_nodes = True
        
        tree = material_neon.node_tree
        
    #Removing the Principled Node
        material_neon.node_tree.nodes.remove(material_neon.node_tree.nodes.get('Principled BSDF'))
    #Create a reference to the Material Ouput
        material_output = material_neon.node_tree.nodes.get('Material Output')
    #Set location of node
        material_output.location = (400,0)
    
    #Adding glass1 node   
        emiss_node = material_neon.node_tree.nodes.new("ShaderNodeEmission")
    #Set location of node
        emiss_node.location = (200,0)
    #change color
        emiss_node.inputs[0].default_value = (0.0938496, 0.589156, 1, 1)
    #change IOR
        emiss_node.inputs[1].default_value = 2
        
        emiss_node.inputs[1].keyframe_insert("default_value",frame=cur_frame)        
        data_path = f'nodes["{emiss_node.name}"].inputs[1].default_value'
        fcurves = tree.animation_data.action.fcurves
        
        fc = fcurves.find(data_path)
        if fc:
            #new_mod = bpy.ops.graph.fmodifier_add(type='NOISE')
            #new_mod = fc.graph.fmodifier_add('NOISE')
            new_mod = fc.modifiers.new('NOISE')
            new_mod.strength = 10
            new_mod.depth =1
        material_neon.node_tree.links.new(emiss_node.outputs[0],material_output.inputs[0])
    
        return{'FINISHED'}    
    
    

def register():
    bpy.utils.register_class(HelloWorldPanel)
    bpy.utils.register_class(SHADER_OT_NEON)


def unregister():
    bpy.utils.unregister_class(HelloWorldPanel)
    bpy.utils.unregister_class(SHADER_OT_NEON)

if __name__ == "__main__":
    register()
