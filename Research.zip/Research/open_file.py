import bpy
from bpy.props import (StringProperty,PointerProperty)
from bpy.types import (panel,PropertyGroup)

class MyProperties(PropertyGroup):
    path:StringProperty(
        name="",
        description ="Path to Directory",
        default="",
        maxlen=1024,
        subtype="DIR_PATH"
    )
    
class OBJECT_PT_CustomPanel(Panel):
    bl_idname = "OBJECT_PT_my_panel"
    bl_label = "My panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tools"
    bl_context = "objectmode"
    
    def draw(self,context):
        layout = self.layout
        scn = context.scene
        col = layout.column(align=True)
        col.prop(scn.my_tool,"path",text="")
        
        print(scn.my_tool.path)
        
classes = (
    MyProperties,
    OBJECT_PT_CustomPanel
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.my_tool = PointerProperty(type=MyProperties)
    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.my_tool
    
if __name__=="__main__":
    register()