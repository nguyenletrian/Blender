bl_info = {
    "name":"Object Adder",
    "author":"NLTA",
    "verison":(1,0),
    "blender":(2,80,0),
    "location":"View3D > Tool",
    "warning":"",
    "wiki_url":"",
    "category":"Object",
}

import bpy

class PanelA(bpy.types.Panel):
    bl_label = "Panel A"
    bl_idname = "PT_PanelB"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "My 1st Addon" # Tab name
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw(self,context):
        layout = self.layout
        row = layout.row()
        row.label(text="Panel A",icon="TIME")
        row.operator("mesh.primitive_cube_add")


class PanelB(bpy.types.Panel):
    bl_label = "Panel B"
    bl_idname = "PT_PanelA"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "My 1st Addon" # Tab name
    bl_parent_id = "PT_PanelB"
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw(self,context):
        layout = self.layout
        layout.scale_y = 1.4        
        obj = context.object
        row = layout.row()
        row.label(text="Panel B",icon="TIME")
        row.operator("mesh.primitive_cube_add")
        row = layout.row()
        row.operator("wm.myop",icon="TIME")
        row = layout.row()
        row.operator("object.text_add",icon="TIME")
        row = layout.row()
        row.operator("transform.resize")
        row = layout.row()
        row.prop(obj,"scale")
        col = layout.column()
        col.prop(obj,"scale")
        row = layout.row()
        row.operator("object.shade_smooth",icon="MOD_SMOOTH",text="Smooth")
        row = layout.row()
        row.operator('object.subdivision_set',icon="MOD_SMOOTH",text="Subdivision")
        row = layout.row()
        row.operator('object.modifier_add',icon="MOD_SMOOTH",text="Modifier")
        
class WM_OT_myOp(bpy.types.Operator):
    """Open the Add Cube Dialog box"""
    bl_label = "Add Cube Dialog Box"
    bl_idname = "wm.myop"
    
    text = bpy.props.StringProperty(name="Enter Text",default="nguyen le tri an")
    #number = bpy.props.FloatProperty(name="Scale Z Axis",default=1)
    scale = bpy.props.FloatVectorProperty(name="Scale:",default=(1,1,1))
    
    def execute(self,context):
        t = self.text
        #n = self.number
        s = self.scale
        bpy.ops.mesh.primitive_cube_add()
        obj = bpy.context.object
        #obj.name = t        obj.name = "nguyen le tri an"
        #obj.scale[2] = n
        obj.scale[0] = s[0]
        obj.scale[1] = s[1]
        obj.scale[2] = s[2]
        
        return{'FINISHED'}
    
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self)
               
def register():
    bpy.utils.register_class(PanelA)
    bpy.utils.register_class(PanelB)
    bpy.utils.register_class(WM_OT_myOp)
    
    
def unregister():
    bpy.utils.unregister_class(PanelA)
    bpy.utils.unregister_class(PanelB)
    bpy.utils.unregister_class(WM_OT_myOp)

if __name__ == "__main__":
    register()