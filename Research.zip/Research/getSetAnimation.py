import bpy
"""
obj = bpy.context.object
bone_groups = obj.pose.bone_groups
bone_groups.active = bone_groups["YourGroupName"]
bpy.ops.pose.group_add()
"""

obj = bpy.data.objects["Lily_Armature"]
newGroup = bpy.ops.pose.group_add()
print(newGroup)
"""
bone_groups = obj.pose.bone_groups
bone_groups.active = bone_groups["YourGroupName"]
bone_groups.active_index = 0  # Set the index of the desired group
bpy.ops.pose.group_assign(type="BONE", name="spine_2_C_1")
"""

"""
import bpy,math

bpy.data.objects["Lily_Armature"].pose.bones["anim_root"]
armature_name = "Lily_Armature"
boneName = "spine_2_C_1"
bpy.ops.object.mode_set(mode="POSE")
bpy.data.objects[armature_name]

poseBones = bpy.context.object.pose.bones
print(poseBones[boneName].rotation_quaternion.x)
print(poseBones[boneName].rotation_quaternion.y)
print(poseBones[boneName].rotation_quaternion.z)
"""

#poseBones["spine_1_C_1"].location.y = 0
#poseBones["spine_1_C_1"].location.z = 0

#theBone = bpy.context.object.pose.bones['spine_2_C_1']
#theBone.location = Vector((1,1,1))
#theBone.rotation_euler = (-1,0,0)
#theBone.rotation_euler[0] = -30
#rotation = theBone.matrix.to_euler()
#print(rotation)



#theBone.rotation_euler = (-1,0,0)
#theBone.keyframe_insert(data_path="rotation_eulder",frame=10)

"""
pose_bone = bpy.context.object.pose.bones[bone_name]




pose_bone.rotation_mode ="XYZ"

axis = "Z"
angle_degrees =  120
angle_radians = math.radians(angle_degrees)

pose_bone.keyframe_insert(data_path="rotation_euler",frame=1)



obj = bpy.data.objects[armature_name].bones[bone_name]
rotate_x = obj.rotation_euler.x
rotate_y = obj.rotation_euler.y
rotate_z = obj.rotation_euler.z
print(rotate_x)
print(rotate_y)
print(rotate_z)

armature =  bpy.data.objects["Lily_Armature"]
boneTarget = armature.pose.bones["spine_2_C_1"]
rotateData = boneTarget.maxtrix.to_euler()
#boneTarget.bone.select = True
print(rotateData)
"""