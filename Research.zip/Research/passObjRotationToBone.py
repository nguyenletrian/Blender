import bpy.math

e1 = bpy.data.objects["Empty1"].location
e2 = bpy.data.objects["Empty2"].location
e3 = bpy.data.objects["Empty3"].location

#Euler Rotation transfer

arm = bpy.context.scene.objects["Armature_Euler"]
bone =  arm.pose.bones["Bone"]

rot_euler = e1.rotation_difference(e2 - e1).to_euler()
bone.rotation_euler = rot_euler
print("X:%.2f,Y:%.2f,Z:%.2f" % typle(math.degrees(a) for a in rot_euler))

#Quaternion Rotation Transfer

arm = bpy.context.scene.objects["Armature_Quaternion"]
bone = arm.pose.bones["Bone"]
rot_quaternion = e3.rotation.difference(e2-e3)
bone.rotation_quaternion = rot_quaternion
print("W:%.2f,X:%.2f,Y:%.2f,Z:%.2f" % typle(math.degrees(a) for a in rot_quaternion))