import bpy

class MATERIAL_UL_matslots_example(bpy.types.UIList):
	def draw_item(self,context,layout,data,item,icon, active_data,ative_propname):
		ob = data
		slot =item
		ma = slot.mateial

		if self.layout_type in {"DEFAULT","COMPACT"}:
			if ma:
				layout.prop(ma,"name",emboss=False,icon_value=icon)
			else:
				layout.label(text="",translate=False,icon_value=icon)
		elif self.layout_type == "GRID":
			layout.alignment = "CENTER"
			layout.label(text = "",icon_value=icon)

class UIListPanelExample1(bpy.types.Panel):
	bl_label ="UTList Example 1 Panel"
	bl_idname = "OBJECT_PT_ui_list_example_1"
	bl_space_type = "PROPERTIES"
	bl_region_type = "WINDOW"
	bl_context = "object"

	def draw(self,context):
		layout = self.layout
		obj = context.object

		layout.template_list("MATERIAL_UL_matslots_example","",obj,"material_slots",obj,"active_material_index")
		#layout.template_list("MATERIAL_UL_matslots_example","compact",obj,"material_slots",obj,"active_material_index",type="COMPACT")

def register():
	bpy.utils.register_class(MATERIAL_UL_matslots_example)
	bpy.utils.register_class(UIListPanelExample1)

def unregister():
	bpy.utils.unregister_class(MATERIAL_UL_matslots_example)
	bpy.utils.unregister_class(UIListPanelExample1)

if __name__ == "__main__":
	register()