import bpy
from bpy_extras.io_utils import ExportHelper
from bpy.types import Operator
from bpy.props import StringProperty
from bpy.utils import register_class

class TEST_OT_export_tst(Operator,ExportHelper):
    bl_idname = "test.export_tst"
    bl_label = "test export test"
    bl_options = {"PRESET","UNDO"}    
    filename_ext = '.abc'
    filter_glob:StringProperty(
        default='*.*',
        options={'HIDDEN'}
    )
    def execute(self,context):
        print('exported file: ',self.filepath)
        return{"FINISHED"}
register_class(TEST_OT_export_tst)
bpy.ops.test.export_tst("INVOKE_DEFAULT")