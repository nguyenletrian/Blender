import bpy

collFrom = bpy.data.collections['Demo']
collTo = bpy.data.collections['NLTA']

to_unlink = []
for obj in collFrom.objects:
    if obj.name not in list(collTo.objects):
        try:
            collTo.objects.link(obj)
        except:pass
        to_unlink.append(obj)

for obj in to_unlink:
    collFrom.objects.unlink(obj)
    
bpy.data.collections.remove(bpy.data.collections['Demo'])

bpy.data.collections['NLTA'].hide_viewport = True
bpy.data.collections['NLTA'].hide_viewport = False
bpy.data.collections['NLTA'].hide_select = True
