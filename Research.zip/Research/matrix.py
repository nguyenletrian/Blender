import bpy

from mathutils import Matrix

"""
# Your string representation of the 4x4 matrix
my_matrix_string = "1 2 3 4; 5 6 7 8; 9 10 11 12; 13 14 15 16"

# Split the string into rows
rows = my_matrix_string.split('; ')

# Extract individual elements and convert them to floats
elements = [list(map(float, row.split(' '))) for row in rows]
array = [
    [1,2,3,4],
    [5,6,7,8],
    [9,11,12,13],
    [14,15,16,17]
]
my_matrix = Matrix(array)
# Create the 4x4 matrix
#my_matrix = Matrix(elements)

#print("Parsed 4x4 matrix:")
print(my_matrix)
"""

#y = x.tolist()

armature = bpy.data.objects["Lily_Armature.001"]
poseBone = armature.pose.bones["spine_1_C_1"]
boneMatrix = poseBone.matrix

boneMatrixToArray = [list(row) for row in boneMatrix]
print(boneMatrixToArray)
backToMatrix = Matrix(boneMatrixToArray)
print(backToMatrix)

