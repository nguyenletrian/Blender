"""
import bpy

scene = bpy.context.scene
for obj in scene.objects:
    obj.location.x +=1.0
"""

"""
bl_indo = {
    "name":"Move X Axis",
    "blender":(2,80,0),
    "category":"Object",
}

import bpy

class ObjectMoveX(bpy.types.Operator):
    #My Object Moving Script          Use this as a tooltop for menu items and buttons.
    bl_idname =  "object.move_x"      #Unique indentifier for buttons and menu items to reference.
    bl_label =  "Move X by One"       #Display name in the interface.
    bl_options = {"REGISTER","UNDO"}  #Enable undo for the operator.
    
    def execute(self,context):        #execute() is called when running the operator.
        #The original script
        scene = context.scene
        for obj in scene.objects:
            obj.location.x += 1.0
        return {"FINISHED"}           #Lest Blender know the operator finished successfully.

def menu_func(self,context):
    self.layout.operator(ObjectMoveX.bl_idname)

def register():
    bpy.utils.register_class(ObjectMoveX)
    bpy.types.VIEW3D_MT_object.append(menu_func) #Adds the new operator to an existing menu.
    
def unregister():
    bpy.utils.unregister_class(ObjectMoveX)
    
#This allows you to run the script directly from Blender's Text editor
#to test the add-on without having to install it.
if __name__ == "__main__":
    register()

"""

"""
import bpy
from bpy import context

#Get the current scene
scene = context.scene

#Get the 3D cursor location
cursor = scene.cursor.location

#Get the active object (assume we have one)
obj = context.active_object

#Now make a copy of the object
obj_new = obj.copy()

#The new object has to be added to collection in the scene
scene.collection.objects.link(obj_new)

#Now we can place the object
obj_new.location = cursor
"""

"""
import bpy
from bpy import context

scene = context.scene
cursor = scene.cursor.location
obj =  context.active_object

#use a fixed value for now, eventually make this user adjustable
total = 10

#add 'total' objects into the scene
for i in range(total):
    obj_new = obj.copy()
    scene.collection.objects.link(obj_new)
    
    factor = i/total
    obj_new.location = (obj.location * factor) + (cursor * (1.0 - factor))
"""

"""

bl_info = {
    "name":"Cursor Array",
    "blender":(2,80,0),
    "category":"Object",
}

import bpy
class ObjectCursorArray(bpy.types.Operator):
    #Object Curror Array
    bl_idname = "object.cursor_array"
    bl_label = "Cursor Array"
    bl_options = {"REGISTER","UNDO"}
    
    def execute(self,context):
        scene =  context.scene
        cursor =  scene.cursor.location
        obj = context.active_object
        
        total = 10
        #total: bpy.props.IntProperty(name="Steps",default=2,min=1,max=100)
        for i in range(total):
            obj_new =  obj.copy()
            scene.collection.objects.link(obj_new)
            
            factor = i/total
            obj_new.location =  (obj.location * factor) + (cursor *(1.0 - factor))
        
        return {"FINISHED"}

def register():
    bpy.utils.register_class(ObjectCursorArray)

def unregister():
    bpy.utils.unregister_class(ObjectCursorArray)
    
if __name__ == "__main__":
    register()

def menu_func(self,context):
    self.layout.operator(ObjectCursorArray.bl_idname)

def register():
    bpy.utils.register_class(ObjectCursorArray)
    bpy.types.VIEW3D_MT_object.appedn(menu_func)
"""

"""

bl_info = {
    "name":"Cursor Array",
    "blender":(2,80,0),
    "category":"Object",
}

import bpy

class ObjectCursorArray(bpy.types.Operator):
    #Object Cursor Array
    bl_idname =  "object.cursor_array"
    bl_label = "Cursor Array"
    bl_options = {"REGISTER","UNDO"}
    
    total: bpy.props.IntProperty(name="Steps",default=2,min=1,max=100)
    
    def execute(self,context):
        scene = context.scene
        cursor = scene.cursor.location
        obj = context.active_object
        
        for i in range (self.total):
            obj_new = obj.copy()
            scene.collection.objects.link(obj_new)
            factor = i/self.total
            obj_new.location = (obj.location * factor) + (cursor * (1.0 - factor))
            
        return {'FINISHED'}
    
def menu_func(self,context):
    self.layout.operator(ObjectCursorArray.bl_idname)
    
#store keymaps here to access after registration
addon_keymaps = []

def register():
    bpy.utils.register_class(ObjectCursorArray)
    bpy.types.VIEW3D_MT_object.append(menu_func)
    
    #handle the keymap
    wm = bpy.context.window_manager
    #Note that in background mode (no GUI available),keyconfigs are not available either,
    #so we have to check this to avoid nasty errors in background case.
    kc = wm.keyconfigs.addon
    if kc:
        km = wm.keyconfigs.addon.keymaps.new(name="Object Mode",space_type="EMPTY")
        kmi = km.keymap_items.new(ObjectCursorArray.bl_idname,"T","PRESS",ctrl=True,shift=True)
        kmi.properties.total = 4
        addon_keymaps.append((km,kmi))
        
def unregister():
    #Node: when unregistering, it's usually good pratice to do it in reverse order you registered.
    #can avoid strange issues like keymap still referring to operators already unregistered...
    #handle the keymap
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    
    bpy.utils.unregister_class(ObjectCursorArray)
    bpy.types.VIEW3D_MT_object.remove(menu_func)
    
if __name__ == "__main__":
    register()
    
"""

"""
import bpy
from bpy.app.handlers import persistent

@persistent
def load_handler_for_preferences(_):
    print("Changing Preference Defaults!")
    from bpy import context
    
    prefs =  context.preferences
    prefs.use_preferences_save = False
    
    kc = context.window_manager.keyconfigs["blender"]
    kc_prefs = kc.preferences
    if kc_prefs is not None:
        kc_prefs.select_mouse =  "RIGHT"
        kc_prefs.spacebar_action = "SEARCH"
        kc_prefs.use_pie_click_drag = True
    
    view.prefs.view
    view.header_align = "BOTTOM"
    
@persistent
def load_handler_for_startup(_):
    print("Changing Startup Defaults!")
    
    #Use smooth faces.
    for mesh in bpy.data.meshes:
        for poly in mesh.polygons:
            poly.use_smooth = True
            
    #Use material preview shading.
    for screen in bpy.data.screens:
        for area in screen.areas:
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.shading.type = "MATERIAL"
                    space.shading.use_scene_lights = True
                    

def register():
    print("Registering to Change Defaults")
    bpy.app.handlers.load_factory_preferences_post.append(load_handler_for_preferences)
    bpy.app.handlers.load_factory_startup_post.append(load_handler_for_startup)
    
def unregister():
    print("Unregistering to change defualts")
    bpy.app.handlers.load_factory_preferences_post.remove(load_handler_for_preferences)
    bpy.app.handlers.load_factory_startup_post.remove(load_handler_for_startup)

"""

"""
print("aaaaa")
import bpy

#print all objects
for obj in bpy.data.objects:
    print(obj.name)

#print all scene names in a list
print(bpy.data.scenes.keys())

#remove mesh Cube
if "Cube" in bpy.data.meshes:
    mesh = bpy.data.meshes["Cube"]
    print("removing mesh",mesh)
    bpy.data.meshes.remove(mesh)
    
#write images into a file next to be blend
import os
with open(os.path.splitext(bpy.data.filepath)[0]+".txt","w") as fs:
    for image in bpy.data.images:
        fs.write("%s %d x %d\n" % (image.filepath,image.size[0],image.size[1]))
"""

bl_info = {
    "name":"Object Adder",
    "author":"NLTA",
    "verison":(1,0),
    "blender":(2,80,0),
    "location":"View3D > Tool",
    "warning":"",
    "wiki_url":"",
    "category":"Object",
}

import bpy

class PanelA(bpy.types.Panel):
    bl_label = "Panel A"
    bl_idname = "PT_PanelB"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "My 1st Addon" # Tab name
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw(self,context):
        layout = self.layout
        row = layout.row()
        row.label(text="Panel A",icon="TIME")
        row.operator("mesh.primitive_cube_add")


class PanelB(bpy.types.Panel):
    bl_label = "Panel B"
    bl_idname = "PT_PanelA"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "My 1st Addon" # Tab name
    bl_parent_id = "PT_PanelB"
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw(self,context):
        layout = self.layout
        layout.scale_y = 1.4        
        obj = context.object
        row = layout.row()
        row.label(text="Panel B",icon="TIME")
        row.operator("mesh.primitive_cube_add")
        row = layout.row()
        row.operator("mesh.primitive_uv_sphere_add",icon="TIME")
        row = layout.row()
        row.operator("object.text_add",icon="TIME")
        row = layout.row()
        row.operator("transform.resize")
        row = layout.row()
        row.prop(obj,"scale")
        col = layout.column()
        col.prop(obj,"scale")
        row = layout.row()
        row.operator("object.shade_smooth",icon="MOD_SMOOTH",text="Smooth")
        row = layout.row()
        row.operator('object.subdivision_set',icon="MOD_SMOOTH",text="Subdivision")
        row = layout.row()
        row.operator('object.modifier_add',icon="MOD_SMOOTH",text="Modifier")
        

               
def register():
    bpy.utils.register_class(PanelA)
    bpy.utils.register_class(PanelB)
    
def unregister():
    bpy.utils.unregister_class(PanelA)
    bpy.utils.unregister_class(PanelB)

if __name__ == "__main__":
    register()