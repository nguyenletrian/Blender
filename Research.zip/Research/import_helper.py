import bpy
import os
from bpy.types import Operator
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

class ImportSomeData(Operator, ImportHelper):
    bl_idname = "import.test"
    bl_label = "Import Some Data"
    
    open_file_browser: BoolProperty(default=True, options={'HIDDEN'})
    file: StringProperty(options={'HIDDEN'})
    filter_glob: StringProperty(options={'HIDDEN'},default='*.abc')# default='*.jpg;*.jpeg;*.png;*.bmp'
    
    def invoke(self, context, event):
        if self.open_file_browser:
            # Open the File Browser
            fileName = context.window_manager.fileselect_add(self)            
            return {'RUNNING_MODAL'}
        else:
            # Do not open the File Browser, perform the operator immediately
            return self.perform_operator()
    
    def execute(self, context):
        self.file = self.filepath
        print(self.filePath)
        return self.perform_operator()
    
    def perform_operator(self):
        if os.path.isfile(self.file):
            bpy.data.images.load(self.file)
            return {'FINISHED'}

class LayoutDemoPanel(bpy.types.Panel):
    bl_label = "Layout Demo"
    bl_idname = "SCENE_PT_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "scene"
    
    def draw(self, context):
        layout = self.layout
        
        # Button 1: Import file from File Browser
        ops = layout.operator("import.test", text="Load")
        ops.open_file_browser = True
        
        # Button 2: Import file from a known path
        ops = layout.operator("import.test", text="Load")
        ops.open_file_browser = False
        ops.file = "c:\\my_file_path\\my_file.jpg"

def register():
    bpy.utils.register_class(LayoutDemoPanel)
    bpy.utils.register_class(ImportSomeData)

def unregister():
    bpy.utils.unregister_class(LayoutDemoPanel)
    bpy.utils.unregister_class(ImportSomeData)

if __name__ == "__main__":
    register()