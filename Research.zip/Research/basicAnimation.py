import bpy,math

print(math.degrees(1))
print(math.radians(57.29577951308232))

def boneAutoKeyframe():
    bpy.context.active_pose_bone.rotation_mode = "XYZ"
    bpy.context.active_pose_bone.rotation_euler.rotate_axis("X",math.radians(60))
    bpy.ops.anim.keyframe_insert()

def getBoneAnimationData(armature):
    armature= bpy.data.objects[armature]
    action = armature.animation_data.action
    curveData = {}
    axis_name = ["X","Y","Z"]
    quat_name = ["W","X","Y","Z"]
    for curve in action.fcurves:
        #GET AXIS       
        curveType = (curve.data_path).split(".")[-1]
        if curveType in ["location","rotation_euler","rotation_quaternion","scale"]:
            if "quaternion" in curveType:
                axis = quat_name[curve.array_index]
            else:
                axis = axis_name[curve.array_index]
        curveName = curveType+axis
        curveData[curveName] = {
            "data_path":curve.data_path,
            "index":curve.array_index,
        }
        
        #GET BONE NAME
        boneName = (curve.data_path).split('"')[1]
        curveData[curveName]["boneName"]=boneName
        
        keyTime = []
        keyValue = []       
        keyframePoints = curve.keyframe_points
        for keyframe in keyframePoints:
            keyTime.append(keyframe.co[0])
            keyValue.append(keyframe.co[1])
        curveData[curveName]["keyTime"]=keyTime
        curveData[curveName]["keyValue"]=keyValue
    return curveData
        
def insertKeyframe(data):
    armature = data["armature"]
    data_path = data["data_path"]
    array_index = data["array_index"]
    frame = data["frame"]
    value = data["value"]
    
    armature= bpy.data.objects["Armature"]
    action = armature.animation_data.action
    fcurve = action.fcurves.find(data_path, index=array_index)    
    keyframe = fcurve.keyframe_points.insert(frame=frame,value=value)
    if "interpolation" in data:
        keyframe.interpolation = data["interpolation"]
    if "handle_left" in data:
        keyframe.handle_left = data["handle_left"]
    if "handle_left_type" in data:
        keyframe.handle_left_type = data["handle_left_type"]
    if "handle_right" in data:
        keyframe.handle_right = data["handle_right"]
    if "handle_right_type" in data:
        keyframe.handle_right_type = data["handle_right_type"]

def deleteKeyframe(data):
    armature = data["armature"]
    data_path = data["data_path"]
    array_index = data["array_index"]
    frame = data["frame"]
    
    armature= bpy.data.objects["Armature"]
    action = armature.animation_data.action
    fcurve = action.fcurves.find(data_path, index=array_index)    
    fcurve.keyframe_delete(data_path=data_path,frame=frame)

