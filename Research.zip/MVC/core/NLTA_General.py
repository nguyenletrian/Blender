import bpy

def createEmptyFromBone(armatureName,boneName):
	armature = bpy.data.objects[armatureName]
	poseBone = armature.pose.bones[boneName]
	armatureMatrix = armature.matrix_world
	poseBoneMatrix = poseBone.matrix    
	resultMatrix = armatureMatrix @ poseBoneMatrix    
	
	bpy.ops.object.mode_set(mode="OBJECT")
	bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location= (0,0,0), scale=(1, 1, 1))
	empty = bpy.context.selected_objects[0]
	empty.matrix_world = resultMatrix
	return(empty)

def getArmature():
	poseBone = bpy.context.active_pose_bone
	return(poseBone.id_data)

def getBoneMatrix(armature,poseBone):
	armature = bpy.data.objects[armatureName]
	bonePose = armature.pose.bones[boneName]
	return(armature.matrix_world @ poseBone.matrix)

def matchBoneToObject(armatureName,boneName,object):
	armature = bpy.data.objects[armatureName]
	poseBone = armature.pose.bones[boneName]
	object = bpy.data.objects[object]
	
	#objectMatrix = object.matrix_world
	#poseBoneNewMatrix =  armature.matrix_world.inverted() @ objectMatrix
	#poseBone.matrix = poseBoneNewMatrix
	poseBone.location.x =20
	
def matchObjectToBone(armatureName,boneName,object):
	armature = bpy.data.objects[armatureName]
	poseBone = armature.pose.bones[boneName]
	object = bpy.data.objects[object]    
	matrixFinal = armature.matrix_world @ poseBone.matrix
	object.matrix_world = matrixFinal

def matchBoneToBone(armatureName1,boneName1,armatureName2,boneName2):
	armature1 = bpy.data.objects[armatureName1]
	poseBone1 = armature1.pose.bones[boneName1]
	armature2 = bpy.data.objects[armatureName2]
	poseBone2 = armature2.pose.bones[boneName2]
	
	poseBone1Matrix = armature1.matrix_world @ poseBone1.matrix
	poseBone2Matrix = armature2.matrix_world.inverted() @ poseBone1Matrix
	poseBone2.matrix = poseBone2Matrix

def boneAutoKeyframe():
	bpy.context.active_pose_bone.rotation_mode = "XYZ"
	bpy.context.active_pose_bone.rotation_euler.rotate_axis("X",math.radians(60))
	bpy.ops.anim.keyframe_insert()


	"""
	if myProp.scaleExample!="":
		armatureScene = bpy.data.objects[myProp.scaleExample]
		heightScene = armatureScene.dimensions.y
		armatureFbx = armature
		heightFbx = armatureFbx.dimensions.y
		ratio = (heightScene / heightFbx)/100
		armatureFbx.scale = (ratio,ratio,ratio)
	"""
		
def insertKeyframe(data):
	armature = data["armature"]
	data_path = data["data_path"]
	array_index = data["array_index"]
	frame = data["frame"]
	value = data["value"]
	
	armature= bpy.data.objects["Armature"]
	action = armature.animation_data.action
	fcurve = action.fcurves.find(data_path, index=array_index)    
	keyframe = fcurve.keyframe_points.insert(frame=frame,value=value)
	if "interpolation" in data:
		keyframe.interpolation = data["interpolation"]
	if "handle_left" in data:
		keyframe.handle_left = data["handle_left"]
	if "handle_left_type" in data:
		keyframe.handle_left_type = data["handle_left_type"]
	if "handle_right" in data:
		keyframe.handle_right = data["handle_right"]
	if "handle_right_type" in data:
		keyframe.handle_right_type = data["handle_right_type"]

def deleteKeyframe(data):
	armature = data["armature"]
	data_path = data["data_path"]
	array_index = data["array_index"]
	frame = data["frame"]
	
	armature= bpy.data.objects["Armature"]
	action = armature.animation_data.action
	fcurve = action.fcurves.find(data_path, index=array_index)    
	fcurve.keyframe_delete(data_path=data_path,frame=frame)


def getDistanceBetween(objFromName,objToName):
	objFrom = bpy.data.objects[objFromName]
	objTo = bpy.data.objects[objToName]
	locationFrom = objFrom.matrix_world.to_translation()
	locationTo = objFrom.matrix_world.to_translation()
	return((locationTo -  locationFrom).length)


def objTypes():
	types = bpy.context.object.bl_rna.properties['type'].enum_items
	for t in types:
		print(f'Type {t.identifier}: {t.name}')

def cleanUp():
	if(bpy.context.active_object):
		bpy.ops.object.mode_set(mode="OBJECT")
		bpy.ops.object.select_all(action="DESELECT")
		
	for item in bpy.data.objects:
		if item.name[0:10] == "temp_Empty":
			bpy.data.objects[item.name]
			bpy.ops.object.delete()
