import bpy,os
from .core.NLTA_General import *
from .properties.NLTA_Properties import *
from .operators.NLTA_Operators import * 
from .panels.NLTA_Panels import *
bl_info = {
    "name":"Sparx* Tools",
    "description":"Sparx*'s Tools",
    "author":"myname",
    "version":(1,0,0),
    "blender":(2,7,9),
    "category":"Animation",
    "location":"VIEW 3D",
}
classArray = [  
    myProperties_PG,
    mainForm_PT,
    #animationUI_PT,   
    setupUI_PT,
    setPair_OP,
    setMirror_OP,   
    loadFbx_OP,
    getFbxData_OP,
    deleteFbx_OP,
    import_OP,
    export_OP,
    pastAnimation_OP,
    reloadScript_OP,
    createEmpty_OP,
    createBone_OP,
    createBoneAnimtion_OP,
    scaleExample_OP,
    fixScale_OP
]
def register():
    for classItem in classArray:
        bpy.utils.register_class(classItem)
    bpy.types.Scene.myProp = bpy.props.PointerProperty(type=myProperties_PG)
def unregister():
    for classItem in classArray:
        bpy.utils.unregister_class(classItem)
if __name__ == "__main__":
    register()