import bpy
bpy.types.Scene.session = {
	"sourceSideLeft":"",
	"sourceSideRight":"",
	"targetSideLeft":"",
	"targetSideRight":"",
	"scaleExampleArmature":"",
	"scaleExampleBone":"",
	"exportFolder":"",
	"importFile":"",
	"frameMin":0,
	"frameMax":0,
	"armatureSource":"",
	"armatureTarget":"",
	"boneAnimationData":[],
}
class myProperties_PG(bpy.types.PropertyGroup):
	session = bpy.types.Scene.session
	sourceSideRight:bpy.props.StringProperty(name="R",default=session["sourceSideRight"])
	sourceSideLeft:bpy.props.StringProperty(name="L",default=session["sourceSideLeft"])
	targetSideRight:bpy.props.StringProperty(name="R",default=session["targetSideRight"])
	targetSideLeft:bpy.props.StringProperty(name="L",default=session["targetSideLeft"])
	scaleExampleArmature:bpy.props.StringProperty(name="scaleExampleArmature",default=session["scaleExampleArmature"])
	scaleExampleBone:bpy.props.StringProperty(name="scaleExampleBone",default=session["scaleExampleBone"])
	exportFolder: bpy.props.StringProperty(
		name = "Custom Path",
		description = "Choose a directory:",
		subtype = "DIR_PATH",
		default=session["exportFolder"]
	)
	importFile: bpy.props.StringProperty(
		name = "Custom Path",
		description ="Choose a directory:",
		subtype = "FILE_PATH",
		default=session["importFile"]
	)