import bpy, math, os, sys, json, functools, datetime
from mathutils import Matrix
from bpy.types import Operator
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

class loadFbx_OP(bpy.types.Operator, ImportHelper):
	bl_label = "Create Animation"
	bl_idname = "animation.load_fbx"
	file: StringProperty(options={'HIDDEN'})
	filter_glob: StringProperty(options={'HIDDEN'},default='*.fbx')# default='*.jpg;*.jpeg;*.png;*.bmp'
	def invoke(self,context,event):
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}

	def execute(self, context):
		myProp = context.scene.myProp
		session = bpy.types.Scene.session

		oldCollection = bpy.data.collections.get("NLTACollection")
		if oldCollection:
			for obj in oldCollection.objects:
				bpy.data.objects.remove(obj,do_unlink=True)
			bpy.data.collections.remove(oldCollection)
		new_collection = bpy.data.collections.new("NLTACollection")
		bpy.context.scene.collection.children.link(new_collection)
		layer_collection = bpy.context.view_layer.layer_collection.children[new_collection.name]
		bpy.context.view_layer.active_layer_collection = layer_collection
		bpy.ops.import_scene.fbx(filepath = self.filepath)

		armature =  new_collection.objects[0]
		session["armatureSource"] = armature.name

		session["boneAnimationData"] = {
			"boneOrder":[]
		}

		#GET BONE ORDER
		for bone in armature.data.bones:
			session["boneAnimationData"]["boneOrder"].append({
				"source":bone.name,
				"target":""
			})
		print("-------------------")
		print(session["boneAnimationData"]["boneOrder"])
		return{'FINISHED'}

class getFbxData_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.get_fbx_data"
	def execute(self, context):
		myProp = context.scene.myProp
		session = bpy.types.Scene.session
		armature =bpy.data.objects[session["armatureSource"]]
		action = armature.animation_data.action
		sessionAnimation = bpy.types.Scene.session["boneAnimationData"]
		sessionAnimation["action"] = action.name
		sessionAnimation["animation"] = {}

		curveData = {}
		frameMin = 0
		frameMax = 0
		axis_name = ["X","Y","Z"]
		quat_name = ["W","X","Y","Z"]	

		frameArray = []
		for curve in action.fcurves:
			#GET BONE NAME
			boneName = (curve.data_path).split('"')[1]
			if boneName not in sessionAnimation["animation"]:
				sessionAnimation["animation"][boneName] = {}

			#GET AXIS       
			curveType = (curve.data_path).split(".")[-1]
			if curveType in ["location","rotation_euler","rotation_quaternion","scale"]:
				if "quaternion" in curveType:
					axis = quat_name[curve.array_index]
				else:
					axis = axis_name[curve.array_index]
			curveName = curveType+axis

			sessionAnimation["animation"][boneName][curveName] = {
				"data_path":curve.data_path,
				"index":curve.array_index,
			}
					
			keyTime = []
			keyValue = []       
			keyframePoints = curve.keyframe_points
			for keyframe in keyframePoints:
				frame = int(keyframe.co[0])
				keyTime.append(frame)
				keyValue.append(keyframe.co[1])
				if frame < frameMin:
					frameMin = frame
				if frame > frameMax:
					frameMax = frame

				if frame not in frameArray:
					frameArray.append(frame)
				
			sessionAnimation["animation"][boneName][curveName]["keyTime"]=keyTime
			#returnDict["animation"][boneName][curveName]["keyValue"]=keyValue
		sessionAnimation["frameMin"] = frameMin
		sessionAnimation["frameMax"] = frameMax
		sessionAnimation["frameArray"] = sorted(frameArray)

		sessionAnimation["matrixData"] = {}
		for frame in sessionAnimation["frameArray"]:
			bpy.context.scene.frame_set(frame)
			frameData = {}
			for bone in armature.data.bones:
				poseBone = armature.pose.bones[bone.name]
				poseBoneMatrix = getBoneMatrix(armature,poseBone)
				poseBoneMatrixToList = [list(row) for row in poseBoneMatrix]
				frameData[bone.name] = poseBoneMatrixToList
			sessionAnimation["matrixData"][frame] = frameData
		return{'FINISHED'}

class import_OP(bpy.types.Operator):
	bl_label = "Import Data"
	bl_idname = "animation.import_data"
	def execute(self, context):
		myProp = context.scene.myProp
		importFile = myProp.importFile
		with open(importFile, "r") as json_file:
			bpy.types.Scene.session = json.load(json_file)		
		session = bpy.types.Scene.session
		myProp.sourceSideRight = session["sourceSideRight"]
		myProp.sourceSideLeft = session["sourceSideLeft"]
		myProp.targetSideRight = session["targetSideRight"]
		myProp.targetSideLeft = session["targetSideLeft"]
		myProp.scaleExample = session["scaleExample"]
		myProp.exportFolder = session["exportFolder"]
		myProp.importFile = session["importFile"]
		self.report({'WARNING'}, "Import complete!")
		return{'FINISHED'}

class pastAnimation_OP(bpy.types.Operator):
	bl_label = "Import Data"
	bl_idname = "animation.past_animation"

	type:bpy.props.StringProperty(default='Location, Rotation & Scale')
	def execute(self, context):
		session = context.scene.session
		armature =  bpy.data.objects[session["armatureTarget"]]
		index = 0

		keyingSet = context.scene.keying_sets_all
		keyingSet.active = keyingSet[self.type]

		animationData = session["boneAnimationData"]

		matrixData = animationData["matrixData"]
		for frame in animationData["frameArray"]:
			bpy.context.scene.frame_set(frame)
			matrixFrameData = matrixData[frame]
			for order in range(len(animationData['boneOrder'])):
				boneSource = animationData['boneOrder'][order]["source"]
				boneTargetName = animationData['boneOrder'][order]["target"]
				if boneTargetName!="":
					boneTarget = armature.pose.bones[boneTargetName]
					maxtriBoneData = Matrix(matrixFrameData[boneSource])
					if boneTarget!="":
						boneTarget.matrix = maxtriBoneData
		return{'FINISHED'}	

class export_OP(bpy.types.Operator):
	bl_label = "Import Data"
	bl_idname = "animation.export_data"
	def execute(self, context):
		session = context.scene.session		
		myProp = context.scene.myProp
		session["sourceSideRight"] = myProp.sourceSideRight
		session["sourceSideLeft"] = myProp.sourceSideLeft
		session["targetSideRight"] = myProp.targetSideRight
		session["targetSideLeft"] = myProp.targetSideLeft
		session["scaleExampleArmature"] = myProp.scaleExampleArmature
		session["scaleExampleBone"] = myProp.scaleExampleBone
		session["exportFolder"] = myProp.exportFolder
		session["importFile"] = myProp.importFile
		folder_temp = myProp.exportFolder
		if folder_temp:
			folder_temp = os.path.join(folder_temp, 'nltaDataFolder')
			if not os.path.exists(folder_temp):
				os.makedirs(folder_temp)
			file_path = folder_temp+"/animationData.json"               
			with open(file_path,"w") as json_file:
				json.dump(session,json_file,indent=4)#sort_keys=False
		self.report({'WARNING'}, "Export complete!")
		return{'FINISHED'}

class setPair_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.set_pair"
	boneSource:bpy.props.StringProperty(name="boneSource")
	def execute(self, context):
		myProp = context.scene.myProp
		session = bpy.types.Scene.session
		sourceSideRight = myProp.sourceSideRight
		sourceSideLeft = myProp.sourceSideLeft
		targetSideRight = myProp.targetSideRight
		targetSideLeft = myProp.targetSideLeft

		activeBone = bpy.context.selected_pose_bones_from_active_object
		if activeBone:
			session["armatureTarget"] = bpy.context.active_object.name
			boneSource = self.boneSource
			boneTarget = activeBone[0].name					
			for a in range(len(session["boneAnimationData"]["boneOrder"])):
				if session["boneAnimationData"]["boneOrder"][a]["source"]==boneSource:
					session["boneAnimationData"]["boneOrder"][a]["target"] = boneTarget

			if sourceSideLeft!="" and targetSideLeft!="":
				boneSourceMirror = boneSource.replace(sourceSideRight,sourceSideLeft)
				boneTargetMirror = boneTarget.replace(targetSideRight,targetSideLeft)
				for a in range(len(session["boneAnimationData"]["boneOrder"])):
					if session["boneAnimationData"]["boneOrder"][a]["source"] == boneSourceMirror:
						session["boneAnimationData"]["boneOrder"][a]["target"] = boneTargetMirror
		else:
			boneSource = self.boneSource
			for a in range(len(session["boneAnimationData"]["boneOrder"])):
				if session["boneAnimationData"]["boneOrder"][a]["source"]==boneSource:
					session["boneAnimationData"]["boneOrder"][a]["target"] = ""

			if sourceSideLeft!="" and targetSideLeft!="":
				boneSourceMirror = boneSource.replace(sourceSideRight,sourceSideLeft)
				for a in range(len(session["boneAnimationData"]["boneOrder"])):
					if session["boneAnimationData"]["boneOrder"][a]["source"] == boneSourceMirror:
						session["boneAnimationData"]["boneOrder"][a]["target"] = ""		
		return{'FINISHED'}

class fixScale_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.fix_scale"
	boneSource:bpy.props.StringProperty(name="boneSource")
	def execute(self, context):
		myProp = context.scene.myProp
		session = bpy.types.Scene.session
		armature1Name = myProp.scaleExampleArmature
		bone1Name = myProp.scaleExampleBone
		armature2Name = session["armatureSource"]
		bone2Name = self.boneSource
		empty1 = createEmptyFromBone(armature1Name,bone1Name)
		empty2 = createEmptyFromBone(armature2Name,bone2Name)
		ratio = (empty1.location.z / empty2.location.z)/100
		armature2 = bpy.data.objects[armature2Name]
		armature2.scale = (ratio,ratio,ratio)

		bpy.ops.object.select_all(action="DESELECT")
		bpy.data.objects[empty1.name].select_set(True)
		bpy.data.objects[empty2.name].select_set(True)
		bpy.ops.object.delete()
		return{'FINISHED'}

class deleteFbx_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.delete_fbx"
	def execute(self, context):
		oldCollection = bpy.data.collections.get("NLTACollection")
		if oldCollection:
			for obj in oldCollection.objects:
				bpy.data.objects.remove(obj,do_unlink=True)
			bpy.data.collections.remove(oldCollection)
		return{'FINISHED'}

class reloadScript_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.reload_script"
	def execute(self, context):
		bpy.ops.script.reload()
		clearProperty(context)
		return{'FINISHED'}

class scaleExample_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.scale_example"
	def execute(self, context):
		myProp = context.scene.myProp
		session = bpy.types.Scene.session
		armature = bpy.context.active_object.name
		session["armatureTarget"] = armature
		activeBone = bpy.context.selected_pose_bones_from_active_object[0]
		if activeBone:
			myProp.scaleExampleArmature = armature
			myProp.scaleExampleBone = activeBone.name
			session["scaleExampleArmature"] = armature
			session["scaleExampleBone"] = activeBone.name
		else:
			myProp.scaleExampleArmature = ""
			myProp.scaleExampleBone = ""
			session["scaleExampleArmature"] = ""
			session["scaleExampleBone"] = ""

		return{'FINISHED'}

class setMirror_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.set_mirror"
	boneSource:bpy.props.StringProperty()

	def execute(self, context):
		session = bpy.types.Scene.session
		sideRight = context.scene.myProp.sideRight
		sideLeft = context.scene.myProp.sideLeft
		activeBone = bpy.context.selected_pose_bones_from_active_object
		if activeBone:
			boneSource = self.boneSource			
			boneTarget = activeBone[0].name
			if sideRight in boneSource:
				boneSourceMirror = boneSource.replace(sideRight,sideLeft)
			if sideLeft in boneSource:
				print("----")
			for a in range(len(session["boneOrder"])):
				if session["boneOrder"][a]["source"]==boneSource:
					session["boneOrder"][a]["target"] = boneTarget
		return{'FINISHED'}

class createEmpty_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "setup.create_empty"
	def execute(self, context):
		arm = bpy.context.active_object
		cleanUp()
		if arm.type == "ARMATURE":
			for pb in arm.pose.bones:
				obj = bpy.data.objects.new("Empty",None)
				obj.name = "temp_"+obj.name
				obj.empty_display_size = .05
				obj.empty_display_type = "CONE"
				bpy.context.scene.collection.objects.link(obj)
				obj.matrix_world = pb.matrix
		else:
			print("Please select an armature")
		return{'FINISHED'}

class createBone_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "setup.create_bone"
	def execute(self, context):
		arm = bpy.context.active_object
		cleanUp()
		if arm.type == "ARMATURE":   
			bpy.ops.object.mode_set(mode="EDIT",toggle=False)
			obArm = bpy.context.active_object
			ebs = obArm.data.edit_bones
			eb = ebs.new("BoneName")
			eb.head = (0,1,1)
			eb.tail = (0,1,2)
		else:
			print("Please select an armature")
		return{'FINISHED'}


class createBoneAnimtion_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "setup.create_animation"
	def execute(self, context):
		#bpy.context.scene.objects.active = ob #active object
		#bpy.ops.object.mode_set(mode="OBJECT")
		arm = bpy.context.active_object
		bpy.ops.object.mode_set(mode="POSE",toggle=False)
		cleanUp()
		if arm.type == "ARMATURE":
			#bonePose = bpy.context.selected_bones[0]
			bonePose = arm.pose.bones["anim_fk_arm_1_L_1"]
			if bonePose:
				#bpy.data.objects[armature.name].data.bones[boneTargetName]
				bonePose = arm.pose.bones["anim_fk_arm_1_L_1"]
				bonePose.rotation_mode = "XYZ"
				bonePose.keyframe_insert(data_path="rotation_euler",frame=1)
				bonePose.rotation_euler.rotate_axis("X",math.radians(90))
				bonePose.keyframe_insert(data_path="rotation_euler",frame=20)
				bonePose.rotation_euler.rotate_axis("X",math.radians(-90))
				bonePose.keyframe_insert(data_path="rotation_euler",frame=40)
				bpy.context.scene.frame_set(0)
		else:
			print("Please select an armature")
		return{'FINISHED'}
