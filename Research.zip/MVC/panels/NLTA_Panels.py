import bpy, math, os, sys, json, functools, datetime
from mathutils import Matrix
from bpy.types import Operator
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ImportHelper
from ..operators.NLTA_Operators import *

class mainForm_PT(bpy.types.Panel):
	bl_label = "Sparx*"
	bl_idname = "NLTA.main"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = 'Sparx tool'
	def draw(self,context):
		layout = self.layout
		layout.scale_y = 1.6
		layout.scale_x = 0.5

class setupUI_PT(bpy.types.Panel):#sub panel
	bl_label = "Setup tool"
	bl_idname = "NLTA.setup"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_parent_id = "NLTA.main"
	bl_options = {"DEFAULT_CLOSED"}#DEK WORK
	def draw(self,context):
		layout = self.layout
		row = layout.row()
		row.operator("animation.load_fbx", text="Get Fbx Data")
		#row.operator("setup.create_bone", text="Create Bone")
		#row = layout.row()
		#row.operator("setup.create_animation", text="Create Animation")
"""
class animationUI_PT(bpy.types.Panel):#sub panel
	bl_label = "Rigging tool"
	bl_idname = "NLTA.animation"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_parent_id = "NLTA.main"
	def draw(self,context):	
		layout = self.layout
		layout.scale_y = 1.6
		myProp = context.scene.myProp
		session = bpy.types.Scene.session

		row = layout.row()
		row.label(text="Source SideFix:")
		row.prop(myProp,"sourceSideRight")
		row.prop(myProp,"sourceSideLeft")

		row = layout.row()
		row.label(text="Target SideFix:")
		row.prop(myProp,"targetSideRight")
		row.prop(myProp,"targetSideLeft")

		row = layout.row()
		row.prop(myProp,"scaleExampleArmature",text="Armature")
		row.prop(myProp,"scaleExampleBone",text="Bone")
		row.operator("animation.scale_example", text="Scale Example")

		row = layout.row()
		row.prop(myProp,"exportFolder")
		row.operator("animation.export_data", text="Export")
		row = layout.row()
		row.prop(myProp,"importFile")
		row.operator("animation.import_data", text="Import")

		row = layout.row(align=True)
		row.operator("animation.load_fbx", text="Load Fbx")
		row.operator("animation.get_fbx_data", text="Get Fbx Data")
		row.operator("animation.delete_fbx", text="Delete Fbx")

		row = layout.row(align=True)
		row.operator("animation.past_animation", text="Past Animation")
		row.operator("animation.reload_script", text="Clear")

		sideRight = myProp.sourceSideRight
		sideLeft = myProp.sourceSideLeft
		boneOrder = session["boneAnimationData"]["boneOrder"]
			
		if len(boneOrder)!=0:
			box = layout.box()		
			for a in range(len(boneOrder)):
				boneName = boneOrder[a]["source"]
				if sideLeft=="":
					row = box.row(align=True)
					row.label(text=boneName)
					setPairOperator = row.operator("animation.set_pair",text=boneOrder[a]["target"])					
					setPairOperator.boneSource = boneName
					fixScaleOperator = row.operator("animation.fix_scale",icon="FACESEL",text="")
					fixScaleOperator.boneSource = boneName
				else:
					if sideLeft not in boneName:
						row = box.row(align=True)
						row.label(text=boneName)
						setPairOperator = row.operator("animation.set_pair",text=boneOrder[a]["target"])					
						setPairOperator.boneSource = boneName
						fixScaleOperator = row.operator("animation.fix_scale",icon="FACESEL",text="")
						fixScaleOperator.boneSource = boneName
"""



