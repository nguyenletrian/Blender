bl_info = {
	"name":"Sparx Rigging tool",
	"author": "Nguyen Le Tri An",
	"version":(1, 0),
	"blender": (2, 80 ,0),
	"location":"VIEW 3D",    
}

import bpy, math, os, sys, json, functools, datetime
from mathutils import Matrix
from bpy.types import Operator
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

def GetCurrentPath ():    
    currentFile = os.path.normpath(__file__)
    path,ext = os.path.splitext(currentFile)
    return(("/").join(path.split("\\")[0:-2])+"/")

print(GetCurrentPath())

user = os.environ.get("USERNAME")
setupFolder = "C:/Users/"+user+"/Documents/maya/scripts/NLTA/"
pathArray = [
"C:/vsTools2/library/python_module/PySide2-5.15.2.1",
"C:/vsTools2/library/python_module/PySide2-5.15.2.1"
]



for path in pathArray:
    if path not in sys.path:
        sys.path.append(path)


from PySide2.QtWidgets import QApplication, QMainWindow, QPushButton,QWidget,QVBoxLayout,QPushButton
from PySide2.QtCore import QTimer,Qt
