import math
def angle(input):    
    return(math.radians(input))