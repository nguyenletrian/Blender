bl_info = {
    "name":"Sparx Rigging tool",
    "author": "Nguyen Le Tri An",
    "version":(1, 0),
    "blender": (2, 80 ,0),
    "location":"VIEW 3D",    
}

import bpy,random,math,sys,os,importlib,inspect

user = os.environ.get("USERNAME")
scriptFoler = "C:/Users/"+user+"/Documents/blender/NLTA"
if scriptFoler not in sys.path:
    sys.path.append(scriptFoler)

classArray = []
for a in ["function","formMain","form"]:
    addPath = scriptFoler+"/"+a
    if addPath not in sys.path:
        sys.path.append(addPath)   
    
    fileList = os.listdir(addPath)
    for b in fileList:
        if b.endswith(".py"):
            libTemp = b.split(".")[0]       
            moduleName = importlib.import_module(libTemp)
            importlib.reload(moduleName) 
            if a != "function":
                moduleClass = moduleName.orderClass()
                for c in moduleClass:
                    classArray.append([c,getattr(moduleName,c)])

class myProperties(bpy.types.PropertyGroup):
    sideRight:bpy.props.StringProperty(name="Right",default="")
    sideLeft:bpy.props.StringProperty(name="Left",default="")

def register():
    for classItem in classArray:
        className = classItem[0]
        if className.endswith("_PN"):#panel
            bpy.utils.register_class(classItem[1])
        elif className.endswith("_OP"):#Operator
            bpy.utils.register_class(classItem[1])
    bpy.utils.register_class(myProperties)
    bpy.types.Scene.myProp = bpy.props.CollectionProperty(type=myProperties)
    

def unregister():
    for classItem in classArray:
        if classItem[0].endswith("_PN"):
            bpy.utils.unregister_class(classItem[1])
        elif className.endswith("_OP"):#Operator
            bpy.utils.unregister_class(classItem[1])
    
if __name__ == "__main__":
    register()