import bpy, math, os
from bpy.types import Operator
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

bpy.types.Scene.session = {"UI":["option1","option2"],"boneOrder":[]}

import bpy
def orderClass():
    return([
        "mainForm_PN"
    ])
    
class mainForm_PN(bpy.types.Panel):
    bl_label = "Sparx*"
    bl_idname = "NLTA.main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Sparx tool'
    def draw(self,context):
        layout = self.layout
        layout.scale_y = 1.6
        layout.scale_x = 0.5


def orderClass():
	return([
		"animationUI_PN",
		"createAnimation_OP",
		"setPair_OP",
		"setMirror_OP"
	])

def objTypes():
	# Get an updated type list (as the API changes sometimes)
	types = bpy.context.object.bl_rna.properties['type'].enum_items
	for t in types:
		print(f'Type {t.identifier}: {t.name}')



class setPair_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.set_pair"
	boneSource:bpy.props.StringProperty(name="boneSource")
	def execute(self, context):
		session = bpy.types.Scene.session
		activeBone = bpy.context.selected_pose_bones_from_active_object
		if activeBone:
			boneSource = self.boneSource			
			boneTarget = activeBone[0].name
			for a in range(len(session["boneOrder"])):
				if session["boneOrder"][a][0]==boneSource:
					session["boneOrder"][a][1] = boneTarget
		else:
			boneSource = self.boneSource
			for a in range(len(session["boneOrder"])):
				if session["boneOrder"][a][0]==boneSource:
					session["boneOrder"][a][1] = ""			
		return{'FINISHED'}

class setMirror_OP(bpy.types.Operator):
	bl_label = "Create Animation"
	bl_idname = "animation.set_mirror"
	boneSource:bpy.props.StringProperty()

	def execute(self, context):
		session = bpy.types.Scene.session
		sideRight = context.scene.myProp.sideRight
		sideLeft = context.scene.myProp.sideLeft
		activeBone = bpy.context.selected_pose_bones_from_active_object
		if activeBone:
			boneSource = self.boneSource			
			boneTarget = activeBone[0].name
			if sideRight in boneSource:
				boneSourceMirror = boneSource.replace(sideRight,sideLeft)
			if sideLeft in boneSource:
				print("----")
			for a in range(len(session["boneOrder"])):
				if session["boneOrder"][a][0]==boneSource:
					session["boneOrder"][a][1] = boneTarget
		return{'FINISHED'}
		"""
		activeBone = bpy.context.selected_pose_bones_from_active_object
		if len(activeBone) != 0:
			boneSource = self.boneSource			
			boneTarget = activeBone[0].name
			for a in range(len(bpy.types.Scene.session["boneOrder"])):
				if bpy.types.Scene.session["boneOrder"][a][0]==boneSource:
					bpy.types.Scene.session["boneOrder"][a][1] = boneTarget
		else:
			boneSource = self.boneSource
			for a in range(len(bpy.types.Scene.session["boneOrder"])):
				if bpy.types.Scene.session["boneOrder"][a][0]==boneSource:
					bpy.types.Scene.session["boneOrder"][a][1] = ""			
		return{'FINISHED'}
		"""


class createAnimation_OP(bpy.types.Operator, ImportHelper):
	bl_label = "Create Animation"
	bl_idname = "animation.load_fbx"
	file: StringProperty(options={'HIDDEN'})
	filter_glob: StringProperty(options={'HIDDEN'},default='*.fbx')# default='*.jpg;*.jpeg;*.png;*.bmp'
	def invoke(self,context,event):
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}

	def execute(self, context):
		oldCollection = bpy.data.collections.get("NLTACollection")
		if oldCollection:
			for obj in oldCollection.objects:
				bpy.data.objects.remove(obj,do_unlink=True)
			bpy.data.collections.remove(oldCollection)
		new_collection = bpy.data.collections.new("NLTACollection")
		bpy.context.scene.collection.children.link(new_collection)
		layer_collection = bpy.context.view_layer.layer_collection.children[new_collection.name]
		bpy.context.view_layer.active_layer_collection = layer_collection
		bpy.ops.import_scene.fbx(filepath = self.filepath)

		


		#obj.animation_data_clear()
		

		#GET MIN FRAME, MAX FRAME
		session = {
			"UI":["option1","option2","option3","option4","option1","option2","option3","option4","option1","option2","option3","option4","option1","option2","option3","option4"],
			"frameMin":0,
			"frameMax":0,
			"boneOrder":[],
			"boneAnimation":[]
		}
		for obj in new_collection.objects:
			armature =  obj
			animData = obj.animation_data.action.fcurves
			for track in range(len(animData)):
				trackData = animData[track].keyframe_points
				for keyframe in trackData:
					minTemp = keyframe.co[0]
					if minTemp < session["frameMin"]:
						session["frameMin"] = minTemp 
					maxTemp = keyframe.co[0]
					if maxTemp > session["frameMax"]:
						session["frameMax"] = maxTemp

		#GET BONE ORDER
		"""
		try:
			bpy.utils.unregister_class(myProperties)		
			del bpy.types.Scene.myProperties
		except:pass

		bpy.utils.register_class(myProperties)
		bpy.types.Scene.myProperties = bpy.props.PointerProperty(type=myProperties)
		bpy.types.Scene.myProperties.option1 = bpy.props.StringProperty(name="Enter Text")
		bpy.types.Scene.myProperties.option2 = bpy.props.StringProperty(name="Enter Text2")
		"""
		for bone in armature.data.bones:
			session["boneOrder"].append([bone.name,"",0,0])#bone name, bone match, mirror, no use		

		"""
		propertiesTemp = context.scene.myProperties_PG
		bpy.utils.unregister_class(myProperties_PG)		
		del bpy.types.Scene.myProperties_PG

		bpy.utils.register_class(myProperties_PG)
		bpy.types.Scene.myProperties_PG = bpy.props.PointerProperty(type=myProperties_PG)
		
        bpy.utils.unregister_class(myProperties_PG)
        setattr(bpy.types.Scene,myProperties_PG,None)
		bpy.utils.register_class(propertiesTemp)
		"""

			#print(getattr(bpy.types.Object,bone.name, None))
			#inputArray.append([bpy.props.StringProperty(name="Enter Text"),bpy.props.StringProperty(name="Enter Text")])
		#session["inputArray"] = inputArray
			
		#GET VALUE
		for frame in range(math.floor(session["frameMin"]),math.ceil(session["frameMax"])):
			bpy.context.scene.frame_set(frame)
			frameData = {}
			for bone in armature.data.bones:				
				pose_bone = armature.pose.bones.get(bone.name)
				boneValue = {
					"px":pose_bone.location.x,
					"py":pose_bone.location.y,
					"pz":pose_bone.location.z,
					"rx":pose_bone.rotation_euler.x,
					"ry":pose_bone.rotation_euler.y,
					"rz":pose_bone.rotation_euler.z,
				}
				frameData[bone.name] = boneValue
			session["boneAnimation"].append(frameData)
		#bpy.context.active_pose_bone.location[0] = 0.174317


		#STANDARDIZED DATA		
		standardData = []
		for keyframe in range(len(session["boneAnimation"])):
			frameData = {}
			for a in range(len(session["boneOrder"])):
				bone = session["boneOrder"][a][0]
				if keyframe == 0:
					currentFrameData = session["boneAnimation"][keyframe][bone]
					beforeFrameData = session["boneAnimation"][keyframe][bone]
				else:
					currentFrameData = session["boneAnimation"][keyframe][bone]
					beforeFrameData = session["boneAnimation"][keyframe - 1][bone]	
				differenceData = {
					"px":currentFrameData["px"] - beforeFrameData["px"],
					"py":currentFrameData["py"] - beforeFrameData["py"],
					"pz":currentFrameData["pz"] - beforeFrameData["pz"],
					"rx":currentFrameData["rx"] - beforeFrameData["rx"],
					"ry":currentFrameData["ry"] - beforeFrameData["ry"],
					"rz":currentFrameData["rx"] - beforeFrameData["rz"]
				}
				frameData[bone] = differenceData
			standardData.append(frameData)
		session["boneAnimation"] = standardData


		oldCollection = bpy.data.collections.get("NLTACollection")
		if oldCollection:
			for obj in oldCollection.objects:
				bpy.data.objects.remove(obj,do_unlink=True)
			bpy.data.collections.remove(oldCollection)

		bpy.types.Scene.session = session

		"""
		#for keyframe in :
			#frame, value = keyframe.co
			#print(f"Frame {frame}: Location X = {value}")
			
			for bone in armature.data.bones:
				print(bone.name)
			#GET KEY MAX
			
			for a in range(len(obj.animation_data.action.fcurves)):
				groupName = obj.animation_data.action.fcurves[a].group.name
				if groupName == ""
				print(obj.animation_data.action.fcurves[a].data_path)
				print(obj.animation_data.action.fcurves[a].keyframe_points)
				for keyframe in obj.animation_data.action.fcurves[a].keyframe_points:
					frame, value = keyframe.co
					print(f"Frame {frame}: Location X = {value}")
		"""
			
		"""
			for frame in range(bpy.context.scene.frame_start, bpy.context.scene.frame_end + 1):
				print(frame)
				bpy.context.scene.frame_set(frame)

				for bone in armature.data.bones:
					if bone.name == "spine_1_C_1":
						print("--------------------")
						print(bone.name)
						pose_bone = armature.pose.bones.get(bone.name)
						x_location = pose_bone.location.x
						print(x_location)
		"""
		"""
			for a in range(len(obj.animation_data.action.fcurves)):
				groupName = obj.animation_data.action.fcurves[a].group.name
				if groupName == ""
				print(obj.animation_data.action.fcurves[a].data_path)
				print(obj.animation_data.action.fcurves[a].keyframe_points)
				for keyframe in obj.animation_data.action.fcurves[a].keyframe_points:
					frame, value = keyframe.co
					print(f"Frame {frame}: Location X = {value}")
		"""
		"""
			for keyframe in fcurve.keyframe_points:
				# Get the frame number (x-coordinate of the keyframe)
				frame = keyframe.co[0]
				# Set the scene frame to the current keyframe
				bpy.context.scene.frame_set(frame)
				# Retrieve the object's location at this frame
				location_x = obj.location.x
				print(f"Frame {frame}: X-coordinate = {location_x:.4f}")

			# Get the active pose bone (replace 'my_bone_name' with your bone's name)
			pb = bpy.context.active_pose_bone

			# Set the bone location (for example, along the X-axis)
			pb.location = (1, 0, 0)

			# Insert a keyframe for the bone's location at frame 10
			pb.keyframe_insert("location", frame=10)
		"""


		"""


		ob = bpy.context.object
		ob.location = (1, 2, 4)  # Set the desired location
		ob.keyframe_insert("location", frame=10)  # Add a keyframe at frame 10
		current_frame = bpy.context.scene.frame_current
		obj = bpy.data.objects['Cube']  # Replace with your object name
		obj.keyframe_insert(data_path='location', frame=0)
		obj.location.z += 5
		obj.keyframe_insert(data_path='location', frame=100)
		bpy.context.scene.frame_set(current_frame)
		"""

	    #obj = bpy.context.scene.objects.get(obj_name)
	    #if obj:
	        #obj.select_set(True)  # Select the object

		return{'FINISHED'}
		
		#return {'RUNNING_MODAL'}
		# Hide the root window to show only the dialog
		#layout.prop(context.Scene.session,"path")
		# Ask the user to select a file

		#bpy.ops.file.select_file()
		"""
		bpy.ops.mesh.primitive_cube_add()
		currentObj = bpy.context.active_object
		currentObj.name = "Nguyen le tri an"
		currentObj.keyframe_insert("location",frame=0)
		currentObj.keyframe_insert("rotation_euler",frame=0)
		currentObj.rotation_euler.z = math.radians(0) #math.degrees(radians)
		currentObj.location.z = 2
		currentObj.rotation_euler.z = math.radians(90) #math.degrees(radians)
		currentObj.keyframe_insert("location",frame=60)
		currentObj.keyframe_insert("rotation_euler",frame=60)
		"""
		#bpy.ops.wm.alembic_import(filepath="C:\\Users\\an.nguyen_g\\Desktop\\a.abc", relative_path=True, as_background_job=True)
		#bpy.ops.wm.alembic_import()
		#return{'FINISHED'}



class animationUI_PN(bpy.types.Panel):#sub panel
	bl_label = "Riggingff tool"
	bl_idname = "NLTA.animation"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_parent_id = "NLTA.main"
	bl_options = {"DEFAULT_CLOSED"}#DEK WORK
	def draw(self,context):	
		layout = self.layout
		layout.scale_y = 1.6
		myProp = context.scene.myProp

		row = layout.row()
		row.label(text="Source sideFix")
		row.prop(myProp,"sideRight",text="Right")
		row.prop(myProp,"sideLeft",text="Left")

		row = layout.row()
		layout.operator("animation.load_fbx", text="Load")

		boneOrder = bpy.types.Scene.session["boneOrder"]
		if len(boneOrder)!=0: 
			box = layout.box()		
			for a in range(len(boneOrder)):
				row = box.row()
				row.label(text=boneOrder[a][0])
				newOperator = row.operator("animation.set_pair",text=boneOrder[a][1])
				newOperator.boneSource = boneOrder[a][0]
				newOperator = row.operator("animation.set_mirror",icon="MOD_MIRROR",text="")
				newOperator.boneSource = boneOrder[a][0]


		#bpy.context.scene.tool_settings.use_keyframe_insert_auto = True


		#bpy.data.objects["Lily_Armature"].data.dones["jaw"].select = True
		#mybone = bpy.context.object.pose.bones["name"]
		#mybone.rotation_mode ="YZX"



		"""
		for a in myProperties:
			print(a.value)
		
		row = box.row()
		row.prop(myProperties_PG,"myRandomNumber")
		for a in range(len(bpy.types.Scene.session["boneOrder"])):
			row.prop(myProperties,bpy.types.Scene.session["boneOrder"][a])
		"""


		#ops.open_file_browser = True
		"""
		layout = self.layout
		layout.scale_y = 1.6
		layout.prop(self,"path")
		
		row = layout.row()
		row.label(text="Match transfrom",icon="CON_TRACKTO")
		row.StringProperty(name="Enter Text",default="")
		#print(context.scene.session)
		#layout.prop(context.scene.session,"path",text="")
		#row = layout.row()
		#row.operator("animation.create_animation",text="Create Animation")
		"""

"""
def register():


def unregister():
    bpy.utils.unregister_class(classItem[1])
    del bpy.types.Scene.myProp
    del bpy.types.Scene.session
    
if __name__ == "__main__":
    register()
"""